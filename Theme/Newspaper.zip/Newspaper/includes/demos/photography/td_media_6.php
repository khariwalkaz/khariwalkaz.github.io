<?php
/**
 * Created by ra on 6/13/2015.
 */

td_demo_media::add_image_to_media_gallery('td_author_photo',             "http://demo_content.tagdiv.com/Newspaper_6/photography/author-photo.jpg");