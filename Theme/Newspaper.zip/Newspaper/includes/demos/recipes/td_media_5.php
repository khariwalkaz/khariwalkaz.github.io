<?php
td_demo_media::add_image_to_media_gallery('td_logo_header',             'http://demo_content.tagdiv.com/Newspaper_6/recipes/logo.jpg');
td_demo_media::add_image_to_media_gallery('td_logo_mobile',             'http://demo_content.tagdiv.com/Newspaper_6/recipes/logo-mobile.png');
td_demo_media::add_image_to_media_gallery('td_bg',             'http://demo_content.tagdiv.com/Newspaper_6/recipes/bg.jpg');