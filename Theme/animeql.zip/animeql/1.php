<?
function get_by_curl_link($url){
    $headers = array(
		"User-Agent: googlebot",
        "Content-Type: application/x-www-form-urlencoded",
		"Referer: ".$url,
        );
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);
    curl_setopt($ch, CURLOPT_HEADER, 1);
    curl_setopt($ch, CURLOPT_REFERER, $referer);
    curl_setopt($ch, CURLOPT_COOKIE, $cookie );
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    if($var) {
    curl_setopt($ch, CURLOPT_POST, 1);        
    curl_setopt($ch, CURLOPT_POSTFIELDS, $var);
    }
    curl_setopt($ch, CURLOPT_URL,$url);

    return curl_exec($ch);
}
$url = "http://phimkk.com/xem-phim/huyen-thoai-ve-korra-phan-1/34753-tap-1%202.html";
echo $info_url_html = get_by_curl_link($url);
?>