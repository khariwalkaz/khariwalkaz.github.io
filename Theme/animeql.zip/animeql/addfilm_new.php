<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Content</title>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<style>
.left { float: left;}.right { float: right; }.clr { clear: both;}
</style>
</head>
<script language="JavaScript" type="text/JavaScript">
<!--
function onover(obj,cls){obj.className=cls;}
function onout(obj,cls){obj.className=cls;}
function ondown(obj,url,cls){obj.className=cls; window.location=url;}
//-->
</script>
<body topmargin="0" leftmargin="0">
<table width="100%" height="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td class="style_border" width="7" >&nbsp;</td>
    <td valign="top" class="style"><table width="100%" height="100%" border="0" cellspacing="1" cellpadding="0">
        <tr>
		    <table width="100%" border="0" cellspacing="0" cellpadding="0">
              <tr>
                <td style="padding: 20px;">
<?php
//include('start.php');
function htmltxt($document){
	$search = array('@<script[^>]*?>.*?</script>@si',  // Strip out javascript
				   '@<[\/\!]*?[^<>]*?>@si',            // Strip out HTML tags
				   '@<style[^>]*?>.*?</style>@siU',    // Strip style tags properly
				   '@<![\s\S]*?--[ \t\n\r]*>@'         // Strip multi-line comments including CDATA
	);
	$text = preg_replace($search, '', $document);
	return $text;
}
function xem_web($url) {
	$ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $url);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Googlebot/2.1 (+http://www.google.com/bot.html)');
  curl_setopt($ch, CURLOPT_HEADER, true );
  curl_setopt($ch, CURLOPT_REFERER, 'http://www.google.com');
  curl_setopt($ch, CURLOPT_ENCODING, 'gzip,deflate');
  curl_setopt($ch, CURLOPT_AUTOREFERER, true);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_TIMEOUT, 120);

		$result = curl_exec($ch);
		curl_close($ch);
		return $result;
}

function grabzzzzz($url) {
if (preg_match("#http://phim.clip.vn/watch/(.*?)/(.*?)#s",$url,$id_sr)){
    	$id 	= 	$id_sr[1];
		$id = explode(',', $id);
		$url	=	'http://clip.vn/embed/'.$id[1];		
	}
return $url;
}
function get_by_curl_link($url){
    $headers = array(
		"User-Agent: googlebot",
        "Content-Type: application/x-www-form-urlencoded",
        );
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);
    curl_setopt($ch, CURLOPT_HEADER, 1);
    curl_setopt($ch, CURLOPT_COOKIE, $cookie );
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    if($var) {
    curl_setopt($ch, CURLOPT_POST, 1);        
    curl_setopt($ch, CURLOPT_POSTFIELDS, $var);
    }
    curl_setopt($ch, CURLOPT_URL,$url);

    return curl_exec($ch);
}
if ($_POST['webgrab'] == 'clipvn') {
	$info_url_html = $curl->get($_POST['urlgrab']);
	$url_play = explode('<a href="http://phim.clip.vn/wa', $info_url_html);
	$total_play = count($url_play);
	$total_plays = $total_play-1;

	$info_img = explode('width="216" height="306" src="', $info_url_html);
	$info_img = explode('?v=', $info_img[1]);
	$info_name = explode("<div class='originaltitle'>", $info_url_html);
	$info_name = explode('</div></h1>', $info_name[1]);
	$info_name_en = explode('<div class="title" itemprop="name">
<h1>', $info_url_html);
	$info_name_en = explode('<div class=', $info_name_en[1]);
	$info_daodien = explode('Đạo diễn: <strong>', $info_url_html);
	$info_daodien = explode('</strong></li>', $info_daodien[1]);
	$info_dienvien = explode('Diễn viên: <strong>', $info_url_html);
	$info_dienvien = explode('</strong></li>', $info_dienvien[1]);
	$info_nam = explode('Phát hành: <strong>', $info_url_html);
	$info_nam = explode('</strong></li>', $info_nam[1]);
	$info_sx = explode('Sản xuất: <strong>', $info_url_html);
	$info_sx = explode('</strong></li>', $info_sx[1]);
	$info_time = explode('Thời lượng: <strong>', $info_url_html);
	$info_time = explode('</strong></li>', $info_time[1]);
	$info_tt = explode('<div class="filmdescription" itemprop="description"><p style="text-align: justify;">', $info_url_html);
	$info_tt = explode('<p style="text-align: center;">', $info_tt[1]);
	$info_tt = $info_tt[0];
       // $info_tt = str_replace("'", " ",$info_tt);
	$info_img = explode('itemprop="image" width="216" height="306" src="', $info_url_html);
	$info_img = explode('"', $info_img[1]);
	$tagdienvien = htmltxt($info_dienvien[0]);
	$tagdaodien = htmltxt($info_daodien[0]);
	$tagsx = htmltxt($info_sx[0]);
	$tagnam = htmltxt($info_nam[0]);
	$info_tag	=	get_ascii($info_name[0].", ".$info_name_en[0].", ".$tagdienvien.", ".$tagdaodien.", ".$tagsx.", ".$tagnam);
}
elseif ($_POST['webgrab'] == 'phimletvn') {
	$info_url_html = xem_web($_POST['urlgrab']);
	$url_play = explode('<a rel="nofollow" href="/xem-ph', $info_url_html);
	$total_play = count($url_play);
	$total_plays = $total_play-1;

	$info_img = explode('width="216" height="306" src="', $info_url_html);
	$info_img = explode('?v=', $info_img[1]);
	$info_name = explode('<meta property="og:title" content="', $info_url_html);
	$info_name = explode(' -', $info_name[1]);
	$info_name_en = explode('" />', $info_name[1]);
	$info_daodien = explode('<div class="grid_2 omega label">Đạo diễn:</div><div class="grid_7 alpha">', $info_url_html);
	$info_daodien = explode('</div></div>', $info_daodien[1]);
	$info_dienvien = explode('<div class="grid_2 omega label">Diễn viên:</div><div class="grid_7 alpha">', $info_url_html);
	$info_dienvien = explode('</div></div>', $info_dienvien[1]);
	$info_nam = explode('<div class="grid_2 omega label">Năm:</div><div class="grid_7 alpha">', $info_url_html);
	$info_nam = explode('</div></div>', $info_nam[1]);
	$info_time = explode('<div class="grid_2 omega label">Tập:</div><div class="grid_7 alpha">', $info_url_html);
	$info_time = explode('</div></div>', $info_time[1]);
	$info_tt = explode('Giới thiệu:</div><div class="grid_7 alpha">', $info_url_html);
	$info_tt = explode('</div></div>', $info_tt[1]);
	$info_tt = $info_tt[0];
	$info_img = explode('<meta property="og:image" content="', $info_url_html);
	$info_img = explode('"', $info_img[1]);
	$tagdienvien = htmltxt($info_dienvien[0]);
	$tagdaodien = htmltxt($info_daodien[0]);
	$tagsx = htmltxt($info_sx[0]);
	$tagnam = htmltxt($info_nam[0]);
	$info_tag	=	get_ascii($info_name[0].", ".$info_name_en[0].", ".$tagdienvien.", ".$tagdaodien.", ".$tagsx.", ".$tagnam);
}
elseif ($_POST['webgrab'] == 'phimkk') {
$info_url_html = $curl->get($_POST['urlgrab']);
	$url_play_phim = explode('<a href="xem-phim', $info_url_html);
	$url_play_phim = explode('"', $url_play_phim[1]);
	$url_play_html_phim = 'http://phimkk.com/xem-phim'.$url_play_phim[0];
	$url_play_phim = $curl->get($url_play_html_phim);
	$url_play = explode('href="xem-', $url_play_phim);
	$total_play = count($url_play);
	$total_plays = $total_play-1;
	
	$info_name = explode('<h1>»  ', $info_url_html);
	$info_name = explode('</h1></a>', $info_name[1]);
	$info_name_en = explode('<p class="tt-en"><b>» ', $info_url_html);
	$info_name_en = explode('</b></p>', $info_name_en[1]);
	$info_daodien = explode('<b>» Đạo diễn</b>: ', $info_url_html);
	$info_daodien = explode('</p>', $info_daodien[1]);
	$info_dienvien = explode('<p><b>» Diễn viên</b>: ', $info_url_html);
	$info_dienvien = explode('</p>', $info_dienvien[1]);
	$info_trailer = explode('value="file=', $info_url_html);
	$info_trailer = explode('&', $info_trailer[1]);
	$info_nam = explode('<b>» Năm San Xuất</b>:', $info_url_html);
	$info_nam = explode('</p>', $info_nam[1]);
	$info_sx = explode('<p>Sản xuất: 	<span>', $info_url_html);
	$info_sx = explode('</span></p>', $info_sx[1]);
	$info_time = explode('Tình Trạng</b>: <span>&nbsp;', $info_url_html);
	$info_time = explode('</span></p>', $info_time[1]);
	$info_tt = explode(' <div class="entry movie_description" id="movie_description">', $info_url_html);
	$info_tt = explode('</div>', $info_tt[1]);
	$info_tt = $info_tt[0];
	$tagdienvien = htmltxt($info_dienvien[0]);
	$tagdaodien = htmltxt($info_daodien[0]);
	$tagsx = htmltxt($info_sx[0]);
	$tagnam = htmltxt($info_nam[0]);
        $info_tagg = explode('<h3>TAG Tìm Kiếm</h3></div><br>', $info_url_html);
	$info_tagg = explode('<br><br>', $info_tagg[1]);
	$tagg = htmltxt($info_tagg[0]);
	$info_tag	=	get_ascii($info_name[0].", ".$info_name_en[0].", ".$tagdienvien.", ".$tagdaodien.", ".$tagsx.", ".$tagnam.", ".$tagg);
	$info_img = explode('<img src="', $info_url_html);
	$info_img = explode('"', $info_img[1]);
}
elseif ($_POST['webgrab'] == '24hphim') {
	$info_url_html = xem_web($_POST['urlgrab']);
	$url_play_phim = explode('<a href="http://24hphim.net/xem-phim', $info_url_html);
	$url_play_phim = explode('"', $url_play_phim[1]);
	$url_play_html_phim = 'http://24hphim.net/xem-phim'.$url_play_phim[0];
	$url_play_phim = xem_web($url_play_html_phim);
	$url_play = explode('href="http://24hphim.net/xem-', $url_play_phim);
	$total_play = count($url_play);
	$total_plays = $total_play-1;

	$info_name = explode('<div id="nav2"><div class="container"><h1 class="title">', $info_url_html);
	$info_name = explode('</h1></div></div>', $info_name[1]);
	$info_name_en = explode('<div id="nav2"><div class="container"><h1 class="title">', $info_url_html);
	$info_name_en = explode('</h1></div></div>', $info_name_en[1]);
	$info_daodien = explode('<div itemscope itemtype="http://schema.org/Movie"><dt>Đạo diễn:</dt>', $info_url_html);
	$info_daodien = explode('</dd>', $info_daodien[1]);
	$info_dienvien = explode('<dt>Diễn viên:</dt>', $info_url_html);
	$info_dienvien = explode('</dd>', $info_dienvien[1]);
	$info_nam = explode('<dt>Năm phát hành:</dt>
<dd>', $info_url_html);
	$info_nam = explode(' </dd>', $info_nam[1]);
	$info_time = explode('<dt>Thời lượng:</dt>
<dd>', $info_url_html);
	$info_time = explode('</dd>', $info_time[1]);
	$info_tt = explode('<div class="tab text">', $info_url_html);
	$info_tt = explode('<em>Chúc các bạn ', $info_tt[1]);
	$info_tt = $info_tt[0];
	$info_img = explode('<meta property="og:image" content="', $info_url_html);
	$info_img = explode('"', $info_img[1]);
	$tagdienvien = htmltxt($info_dienvien[0]);
	$tagdaodien = htmltxt($info_daodien[0]);
	$tagsx = htmltxt($info_sx[0]);
	$tagnam = htmltxt($info_nam[0]);
	$info_tag	=	get_ascii($info_name[0].", ".$info_name_en[0].", ".$tagdienvien.", ".$tagdaodien.", ".$tagsx.", ".$tagnam);

}
elseif ($_POST['webgrab'] == 'nuiphimcom') {
	$info_url_html = xem_web($_POST['urlgrab']);
	$url_play_phim = explode('<a href="http://nuiphim.com/xem-phim-online', $info_url_html);
	$url_play_phim = explode('"', $url_play_phim[1]);
	$url_play_html_phim = 'http://nuiphim.com/xem-phim-online'.$url_play_phim[0];
	$url_play_phim = xem_web($url_play_html_phim);
	$url_play = explode('<a href="http://nuiphim.com/xem-phim-', $url_play_phim);
	$total_play = count($url_play);
	$total_plays = $total_play-1;

	$info_name = explode('<h2 class="title-film">', $info_url_html);
	$info_name = explode(' - ', $info_name[1]);
	$info_name_en = explode('</h2>', $info_name[1]);
	$info_daodien = explode('<p>Đạo diễn: <b>', $info_url_html);
	$info_daodien = explode('</b></p>', $info_daodien[1]);
	$info_dienvien = explode('<p>Diễn viên: <b>', $info_url_html);
	$info_dienvien = explode('</b></p>', $info_dienvien[1]);
	$info_nam = explode('title="Phim Năm ', $info_url_html);
	$info_nam = explode('"', $info_nam[1]);
	$info_time = explode('<p class="col2 fl">Thời lượng: <b>', $info_url_html);
	$info_time = explode('</b></p>', $info_time[1]);
	$info_tt = explode('<div class="movie movie-content fl cl">', $info_url_html);
	$info_tt = explode('</div>', $info_tt[1]);
	$info_tt = $info_tt[0];
	$info_img = explode('<div class="poster">
<img src="', $info_url_html);
	$info_img = explode('"', $info_img[1]);
	$tagdienvien = htmltxt($info_dienvien[0]);
	$tagdaodien = htmltxt($info_daodien[0]);
	$tagsx = htmltxt($info_sx[0]);
	$tagnam = htmltxt($info_nam[0]);
	$info_tag	=	get_ascii($info_name[0].", ".$info_name_en[0].", ".$tagdienvien.", ".$tagdaodien.", ".$tagsx.", ".$tagnam);

}
elseif ($_POST['webgrab'] == 'anime-fever') {
	$info_url_html = $curl->get($_POST['urlgrab']);
	$url_play_phim = explode('href="http://anime-fever.com/xem-phim', $info_url_html);
	$url_play_phim = explode('"', $url_play_phim[1]);
	$url_play_html_phim = 'http://anime-fever.com/xem-phim'.$url_play_phim[0];
	$url_play_phim = $curl->get($url_play_html_phim);
	$url_play = explode('<a href="http://anime-fever.com/xem-', $url_play_phim);
	$total_play = count($url_play);
	$total_plays = $total_play-1;
   
	$info_name = explode('<h3 class="tenphim_en">', $info_url_html);
	$info_name = explode('</span></h3>', $info_name[1]);
	$info_name_en = explode('<h2 class="tenphim">', $info_url_html);
	$info_name_en = explode('</h2>', $info_name_en[1]);
	$info_nam = explode('<dt>Năm phát hành:</dt><dd>', $info_url_html);
	$info_nam = explode('</dd>', $info_nam[1]);
	$info_time = explode('<dt>Số Tập:</dt><dd>', $info_url_html);
	$info_time = explode('</dd>', $info_time[1]);
	$info_tt = explode('<div class="info-film-c">', $info_url_html);
	$info_tt = explode('<div class="more-html"></div>', $info_tt[1]);
	$info_tt = $info_tt[0];
      //  $info_tt = get_ascii($info_tt);
        $info_tagg = explode('<dt>Thể loại:</dt><dd>', $info_url_html);
	$info_tagg = explode('</dd>', $info_tagg[1]);
	$tagg = htmltxt($info_tagg[0]);
        $taggnamen = htmltxt($info_name[0]);
	$info_img = explode('<meta name="og:image" content="', $info_url_html);
	$info_img = explode('"', $info_img[1]);
	$tagnam = htmltxt($info_nam[0]);
	$info_tag	=	get_ascii($taggnamen.", ".$info_name_en[0].",".$tagnam.",".$tagg);

}
elseif ($_POST['webgrab'] == 'animefav') {
	$info_url_html = xem_web($_POST['urlgrab']);
	$url_play_phim = explode('<a href="http://animefav.info/xem-phim', $info_url_html);
	$url_play_phim = explode('"', $url_play_phim[1]);
	$url_play_html_phim = 'http://animefav.info/xem-phim'.$url_play_phim[0];
	$url_play_phim = xem_web($url_play_html_phim);
	$url_play = explode('class="" href="http://animefav.info/xem-', $url_play_phim);
	$total_play = count($url_play);
	$total_plays = $total_play-1;

	$info_name = explode('<h3>', $info_url_html);
	$info_name = explode('</h3>', $info_name[1]);
	$info_name_en = explode('<title>Phim   ', $info_url_html);
	$info_name_en = explode(' - ', $info_name_en[1]);
	$info_nam = explode('<p>Năm phát hành: <strong>', $info_url_html);
	$info_nam = explode(' </strong></p>', $info_nam[1]);
	$info_time = explode('<p>Thời lượng: <strong>', $info_url_html);
	$info_time = explode('</strong></p>', $info_time[1]);
	$info_tt = explode('<div id="noidung" class="tabs_content">', $info_url_html);
	$info_tt = explode('<div class="f_d_tag">', $info_tt[1]);
	$info_tt = $info_tt[0];
	$info_img = explode('<meta property="og:image" content="', $info_url_html);
	$info_img = explode('"', $info_img[1]);
	$info_tagg = explode('Tags: ', $info_url_html);
	$info_tagg = explode('</div>', $info_tagg[1]);
	$tagg = htmltxt($info_tagg[0]);
	$tagg = str_replace(' ', ",",$tagg);
	$tagsx = htmltxt($info_sx[0]);
	$tagnam = htmltxt($info_nam[0]);
	$info_tag	=	get_ascii($info_name[0].", ".$info_name_en[0].", ".$tagsx.", ".$tagnam.", ".$tagg);

}
elseif ($_POST['webgrab'] == 'animevn') {
	$info_url_html = $curl->get($_POST['urlgrab']);
	$url_play_phim = explode('href=http://www.animevn.biz/xem-phim', $info_url_html);
	$url_play_phim = explode('>', $url_play_phim[1]);
	$url_play_html_phim = 'http://www.animevn.biz/xem-phim'.$url_play_phim[0];
	$url_play_phim = $curl->get($url_play_html_phim);
	$url_play = explode('<a href="http://www.animevn.biz/xem-', $url_play_phim);
	$total_play = count($url_play);
	$total_plays = $total_play-1;

	$info_name = explode('<h1 class="mvtitle" itemprop="name">', $info_url_html);
	$info_name = explode('</h1>', $info_name[1]);
	$info_name_en = explode('<h1 class="mvtitle" itemprop="name">', $info_url_html);
	$info_name_en = explode('</h1>', $info_name_en[1]);
	$info_daodien = explode('<p><span class="info-phimcms">Đạo diễn:</span> <span class="info-phimcms-2">', $info_url_html);
	$info_daodien = explode('</span></p>', $info_daodien[1]);
	$info_dienvien = explode('<div class="dienvien-gioihan"><span class="info-phimcms">Nhân vật:</span> <span class="info-phimcms-2">', $info_url_html);
	$info_dienvien = explode('</span></div>', $info_dienvien[1]);
	$info_nam = explode('title="Phim năm ', $info_url_html);
	$info_nam = explode('">', $info_nam[1]);
	$info_sx = explode('<p><span class="info-phimcms">Nhà sản xuất:</span> <span class="info-phimcms-2">', $info_url_html);
	$info_sx = explode('</span></p>', $info_sx[1]);
	$info_time = explode('<p><span class="info-phimcms">Số tập anime:</span> <span class="info-phimcms-2">', $info_url_html);
	$info_time = explode('</span></p>', $info_time[1]);
	$info_tt = explode('<div id="description-clip" class="info-desc">', $info_url_html);
	$info_tt = explode('<div id="description-clip-1" class="info-desc-tag"', $info_tt[1]);
	$info_tt = $info_tt[0];
	$info_img = explode('<meta property="og:image" content="', $info_url_html);
	$info_img = explode('"', $info_img[1]);
	$info_tagg = explode('</span>
      </div>
      <div class="message">', $info_url_html);
	$info_tagg = explode('</div>', $info_tagg[1]);
	$tagsx = htmltxt($info_sx[0]);
	$tagnam = htmltxt($info_nam[0]);
	$tagtag = htmltxt($info_tagg[0]);
	$info_trailer = explode('class="btn-cms btn-green" data-id="', $info_url_html);
	$info_trailer = explode('"', $info_trailer[1]);
	$info_tag	=	htmltxt(get_ascii($info_name[0].",".$info_name_en[0]."".$info_daodien[0]."".$tagsx."".$tagnam.",".$info_dienvien[0].",".$tagtag));

}
elseif ($_POST['webgrab'] == 'phim37') {
	$info_url_html = xem_web($_POST['urlgrab']);
	$url_play_phim = explode('"  href="http://phim37.net/xem-phim/online', $info_url_html);
	$url_play_phim = explode('"', $url_play_phim[1]);
	$url_play_html_phim = 'http://phim37.net/xem-phim/online'.$url_play_phim[0];
	$url_play_phim = xem_web($url_play_html_phim);
	$url_play = explode('href="http://phim37.net/xem-', $url_play_phim);
	$total_play = count($url_play);
	$total_plays = $total_play-1;

	$info_name = explode('<p>Tên phim: <span>', $info_url_html);
	$info_name = explode('  <a ', $info_name[1]);
	$info_name_en = explode('<p>Tên phim: <span>', $info_url_html);
	$info_name_en = explode('  <a ', $info_name_en[1]);
	$info_daodien = explode('<p>Đạo diễn: 	<span>', $info_url_html);
	$info_daodien = explode('</span></p>', $info_daodien[1]);
	$info_dienvien = explode('<p>Diễn viên: 	<span>', $info_url_html);
	$info_dienvien = explode('</span></p>', $info_dienvien[1]);
	$info_nam = explode('title="Phim Năm ', $info_url_html);
	$info_nam = explode('">', $info_nam[1]);
	$info_sx = explode('<p>Sản xuất: 	<span>', $info_url_html);
	$info_sx = explode('</span></p>', $info_sx[1]);
	$info_time = explode('<p>Thời lượng: 	<span>', $info_url_html);
	$info_time = explode('</span></p>', $info_time[1]);
	$info_tt = explode('<div class="entry"><b>Nội dung phim:</b> ', $info_url_html);
	$info_tt = explode('<div class="clear"></div>', $info_tt[1]);
	$info_tt = $info_tt[0];
	$info_img = explode('src="http://phim37.net/images', $info_url_html);
	$info_img = explode('"', $info_img[1]);
	$info_img = "http://phim37.net/images/".$info_img[0];
	$info_tagg = explode('<font color="888"><b>TAG : </font></b> ', $info_url_html);
	$info_tagg = explode('</div>', $info_tagg[1]);
	$tagsx = htmltxt($info_sx[0]);
	$tagnam = htmltxt($info_nam[0]);
	$tagtag = htmltxt($info_tagg[0]);
	$tagdd = htmltxt($info_daodien[0]);
	$tagdvien = htmltxt($info_dienvien[0]);
	$info_trailer = explode('class="btn-cms btn-green" data-id="', $info_url_html);
	$info_trailer = explode('"', $info_trailer[1]);
	$info_tag	=	htmltxt(get_ascii($info_name[0].",".$info_name_en[0]."".$tagdd."".$tagsx."".$tagnam.",".$tagdvien.",".$tagtag));

}
elseif ($_POST['webgrab'] == 'phimvang') {
	$info_url_html = xem_web($_POST['urlgrab']);
	$url_play_phim = explode('<p><a href="/xem-phim/', $info_url_html);
	$url_play_phim = explode('"', $url_play_phim[1]);
	$url_play_html_phim = 'http://phim7.com/xem-phim/'.$url_play_phim[0];
	$url_play_phim = xem_web($url_play_html_phim);
	$url_play = explode('<a href="/xem-p', $url_play_phim);
	$total_play = count($url_play);
	$total_plays = $total_play-1;

	$info_name = explode('<p>Tên phim:	<span class="fn">', $info_url_html);
	$info_name = explode(' - ', $info_name[1]);
	$info_name_en = explode('</span></p>', $info_name[1]);
	$info_daodien = explode('<p>Đạo diễn: 	<span class="author">', $info_url_html);
	$info_daodien = explode('</span></p>', $info_daodien[1]);
	$info_dienvien = explode('<p>Diễn viên: 	<span class="ingredient">', $info_url_html);
	$info_dienvien = explode('</span></p>', $info_dienvien[1]);
	$info_nam = explode('<p>Năm sản xuất: 	<span>', $info_url_html);
	$info_nam = explode('</span></p>', $info_nam[1]);
	$info_time = explode('<p>Thời lượng: 	<span>', $info_url_html);
	$info_time = explode('</span></p>', $info_time[1]);
	$info_tt = explode('data-width="1000"></div>', $info_url_html);
	$info_tt = explode('</div>', $info_tt[1]);
	$info_tt = $info_tt[0];
	$info_tagg = explode('<p style="padding-bottom:20px; text-align:justify;">Xem thêm: 	<span>', $info_url_html);
	$info_tagg = explode('</span></p>', $info_tagg[1]);
	$info_img = explode('<link rel="image_src" href="', $info_url_html);
	$info_img = explode('"', $info_img[1]);
	$tagdienvien = htmltxt($info_dienvien[0]);
	$tagdaodien = htmltxt($info_daodien[0]);
	$tagsx = htmltxt($info_sx[0]);
	$tagnam = htmltxt($info_nam[0]);
	$info_tag	=	htmltxt(get_ascii($info_name[0].", ".$info_name_en[0].", ".$tagdienvien.", ".$tagdaodien.", ".$tagsx.", ".$tagnam));

}
elseif ($_POST['webgrab'] == 'anime89') {
	$info_url_html = xem_web($_POST['urlgrab']);
	$url_play_phim = explode('<div class="thumbnail2"><a href="./xem-phim/', $info_url_html);
	$url_play_phim = explode('"', $url_play_phim[1]);
	$url_play_html_phim = 'http://anime89.zapto.org/movie/xem-phim/'.$url_play_phim[0];
	$url_play_phim = xem_web($url_play_html_phim);
	$url_play = explode('<a href="xem-', $url_play_phim);
	$total_play = count($url_play);
	$total_plays = $total_play-1;
   
	$info_name = explode('<h3>', $info_url_html);
	$info_name = explode('</h3>', $info_name[1]);
	$info_name_en = explode('<h1><font color=red><b>Anime Vietsub ', $info_url_html);
	$info_name_en = explode(' - ', $info_name_en[1]);
	$info_nam = explode('<a href="year/', $info_url_html);
	$info_nam = explode('.html"', $info_nam[1]);
	$info_time = explode('<dt>Thời lượng:</dt>
        <dd>', $info_url_html);
	$info_time = explode('</dd>', $info_time[1]);
	$info_daodien = explode('<dt>Đạo diễn:</dt>
        <dd>', $info_url_html);
	$info_daodien = explode('</dd>', $info_daodien[1]);
	$info_dienvien = explode('<dt>Diễn viên:</dt>
        <dd>', $info_url_html);
	$info_dienvien = explode('</dd>', $info_dienvien[1]);
	$info_tt = explode('<div class="small_img1">', $info_url_html);
	$info_tt = explode('</div>', $info_tt[1]);
	$info_tt = $info_tt[0];
	$info_img = explode(' - " src="', $info_url_html);
	$info_img = explode('"', $info_img[1]);
	$info_tagg = explode(' <div style="margin-top:5px;" class="title hr"><span>Tags:</span></div>', $info_url_html);
	$info_tagg = explode('      </div>
    </div>

  </div>
</div>', $info_tagg[1]);
	$tagg = htmltxt($info_tagg[0]);
	$tagg = str_replace(' ', ",",$tagg);
	$tagsx = htmltxt($info_sx[0]);
	$tagnam = htmltxt($info_nam[0]);
	$info_tag	=	get_ascii($info_name[0].", ".$info_name_en[0].", ".$tagsx.", ".$tagnam.", ".$tagg);

}
?>
<?php
$begin = $_POST['episode_begin'];
$end = $_POST['episode_end'];
////BEGIN CHECK EPISODE
if(!is_numeric($begin) && !is_numeric($end)){
if ($_POST['webgrab'] == 'animevn') {
$episode_begin = 2;
}
else
{
$episode_begin = 1;
}
$episode_end = $total_plays;
}elseif(!is_numeric($begin) && !is_numeric($end)){
$episode_begin = 1;
$episode_end = 10;
}elseif(!is_numeric($begin)){
$episode_begin = $episode_end = $end;
}else{
$episode_begin = $begin; $episode_end = $end;
}
////END CHECK EPISODE
if (!$_POST['submit']) {
?>
<script>
var total = <?=$total_links?>;
<? for ($z=1; $z<=$total_sv; $z++) { ?>
    function check_local_<?=$z?>(status){
        for(i=1;i<=total;i++)
            document.getElementById("local_url_<?=$z?>_"+i).checked=status;
    }
<? } ?>
</script>
<form enctype="multipart/form-data" method=post>
<table cellpadding=2 cellspacing=2 width=100% >
<tr>
	<td class=fr width=20%>
		<b>Tên phim</b>
		</td>
	<td class=fr_2>
		<input name="new_phim" value="<?=htmltxt($info_name_en[0])?>" size=50>
	</td>
</tr>
<tr>
	<td class=fr width=20%>
		<b>Tên tiếng anh</b>
		</td>
	<td class=fr_2>
		<input name="tienganh" value="<?=htmltxt($info_name[0])?>" size=50>
	</td>
</tr>
<tr>
	<td class=fr width=20%>
		<b>Đạo diễn</b>
	<td class=fr_2>
		<input name="phim_daodien" value="<?=htmltxt($info_daodien[0])?>" size=50>
	</td>
</tr>
<tr>
	<td class=fr width=20%>
		<b>Diễn viên</b>
	<td class=fr_2>
		<input name="phim_dienvien" value="<?=htmltxt($info_dienvien[0])?>" size=50>
	</td>
</tr>
<tr>
	<td class=fr width=20%>
		<b>Trailer</b>
	<td class=fr_2>
		<input name="trailer" value="<?=htmltxt($info_trailer[0])?>"size=50>
	</td>
</tr>
<tr>
	<td class=fr width=20%>
		<b>Nhà Sản Xuất</b>
	<td class=fr_2>
		<input name="nhasx" value="<?=htmltxt($info_sx[0])?>"size=50>
	</td>
</tr>
<tr>
	<td class=fr width=20%>
		<b>Thời lượng</b>
	<td class=fr_2>
		<input name="phim_thoigian" value="<?=htmltxt($info_time[0])?>" size=50>
	</td>
</tr>
<tr>
	<td class=fr width=20%>
		<b>Năm Phát Hành</b>
	<td class=fr_2>
		<input name="phim_nam" value="<?=htmltxt($info_nam[0])?>" size=50>
	</td>
</tr>
<tr><td class=fr width=100px><font color="red"><b>Tag Seo Google</b></td><td class=fr_2><textarea name="tagseo" style="height: 120px; width: 600px;"><?=$info_tag;?></textarea></td></tr>
<tr><td class="fr" width="30%"><b>QUỐC GIA</b></td><td class="fr_2"><select name="country"><option value="1">- Phim Việt Nam</option><option value="10">- Phim Châu Á</option><option value="11">- Phim Ấn Độ</option><option value="2">- Phim Trung Quốc</option><option value="3">- Phim Hàn Quốc</option><option value="4">- Phim Thái Lan</option><option value="5">- Phim Mỹ</option><option value="6">- Phim Hồng Kông</option><option value="7" selected="">- Phim Nhật Bản</option><option value="8">- Phim Đài Loan</option><option value="9">- Phim Châu Âu</option></select></td></tr>
<tr>
	<td class=fr width=20%>
		<b>Phim Bộ/Lẻ</b></td>
	<td class=fr_2><select name="phimbole"><option value=0>- Phim Lẻ</option><option value=1 selected="">- PhimBộ</option></select></td>
    </tr>
<tr>
<tr>
	<td class=fr width=20%>
		<b>Tập Phim</b>
	<td class=fr_2>
		<input name="tapphim" value="HD"size=50>
	</td>
</tr>
<tr>
	<td class=fr width=20%>
		<b>Img phim</b></td>
	<td class=fr_2>
	<input type=text name="phim_imgz" size=60 value="<?=$info_img[0];?>"></td>
</tr>
<tr>
	<td class=fr width=20%>
		<b>Ảnh Bìa</b></td>
	<td class=fr_2>
	<input type=text name="imgBig" size=60 value=""></td>
</tr>
<tr>
	<td class=fr width=20%><b>Thể loại</b></td>
	<td class=fr_2><?=acp_cat()?></td>
</tr>
<tr>
	<td class=fr width=20%><b>Thông tin: </b></td>
	<td class=fr_2>
		<textarea name="phim_info" id="phim_info" cols="100" rows="15"><?=$info_tt;?><?=$$info_test;?></textarea>
		<script language="JavaScript">generate_wysiwyg('phim_info');</script>
	</td>
</tr>
<tr>

    <td class="fr" width="10%"><b>LOCAL SEVER</b></td>

    <td class="fr_2"><?=acp_local(0,'main')?>
</td>
	</tr>
<tr>

    <td class="fr" width="10%"><b>Server Post</b></td>

    <td class="fr_2"><?php echo set_server(0);?>

</td>	
	</tr>	
					<?php
               //     for ($i=$episode_begin;$i<=$episode_end;$i++) {
 for ($i=$episode_begin;$i<=$episode_end;$i++) {
						if ($_POST['webgrab'] == 'clipvn') {
							$play_url = explode('tch/', $url_play[$i]);
							$play_url = explode('" title="', $play_url[1]);
							$name = explode('Tap', $url_play[$i]);
							$name = explode(',', $name[1]);
							$name = str_replace('Xem phim','',$name[0]);
							$play_url = $play_url[0];
							$play_embed[$i] = grabzzzzz('http://phim.clip.vn/watch/'.$play_url);
						}
						elseif ($_POST['webgrab'] == 'phimletvn') {
							$play_url = explode('im-', $url_play[$i]);
							$play_url = explode('"', $play_url[1]);
							$play_url = "http://phim.let.vn/xem-phim-".$play_url[0];
							$html_link_play = xem_web($play_url);
							$link_phim = explode('proxy.link=', $html_link_play);
							$link_phim = explode('&', $link_phim[1]);
							$link_phim = $link_phim[0];
							$play_embed[$i] = $link_phim;
							$name = explode('<span>', $url_play[$i]);
							$name = explode('</span>', $name[1]);
							$name = str_replace("Tập ","",$name[0]);
						}
						elseif ($_POST['webgrab'] == 'phimkk') {
							$play_url = explode('phim/', $url_play[$i]);
							$play_url = explode('"', $play_url[1]);
							$play_url = 'http://phimkk.com/xem-phim/'.$play_url[0];
							$html_link_play = $curl->get($play_url);
							$link_phim = explode('&file=', $html_link_play);
							$link_phim = explode('&', $link_phim[1]);
							$link_phim = $link_phim[0];
							$play_embed[$i] = $link_phim;
							$name = explode('</span> Tập <font color="#FFFFFF"><span style="background-color: rgb(0, 0, 0);"><b>&nbsp;', $html_link_play);
							$name = explode('&nbsp;', $name[1]);
							$name = $name[0];
						}
						elseif ($_POST['webgrab'] == '24hphim') {
							$play_url = explode('phim-', $url_play[$i]);
							$play_url = explode('"', $play_url[1]);
							$play_url = 'http://24hphim.net/xem-phim-'.$play_url[0];
							$html_link_play = xem_web($play_url);
							$link_phim = explode('"proxy.link": "', $html_link_play);
							$link_phim = explode('",', $link_phim[1]);
							$link_phim = $link_phim[0];
							$play_embed[$i] = $link_phim;
							$name = explode('<h2 class="item last-child">Tập ', $html_link_play);
							$name = explode(' |', $name[1]);
							$name = $name[0];
						}
						elseif ($_POST['webgrab'] == 'phimhayhot') {
							$play_url = explode('online/', $url_play[$i]);
							$play_url = explode('"', $play_url[1]);
							$play_url = 'http://phimhayhot.com/xem-phim/online/'.$play_url[0];
							$html_link_play = xem_web($play_url);
							$link_phim = explode('proxy.link=', $html_link_play);
							$link_phim = explode('&', $link_phim[1]);
							$link_phim = $link_phim[0];
							$play_embed[$i] = $link_phim;
							$name = explode('Tap ', $html_link_play);
							$name = explode(' sv ', $name[1]);
							$name = $name[0];
						}
						elseif ($_POST['webgrab'] == 'nuiphimcom') {
							$play_url = explode('online/', $url_play[$i]);
							$play_url = explode('"', $play_url[1]);
							$play_url = "http://nuiphim.com/xem-phim-online/".$play_url[0];
							$html_link_play = xem_web($play_url);
							$link_phim = explode('proxy.link=', $html_link_play);
							$link_phim = explode('&', $link_phim[1]);
							$link_phim = $link_phim[0];
							$play_embed[$i] = $link_phim;
							$name = explode('TẬP ', $html_link_play);
							$name = explode('">', $name[1]);
							$name = $name[0];
						}
						elseif ($_POST['webgrab'] == 'anime-fever') {
							$play_url = explode('phim/', $url_play[$i]);
							$play_url = explode('"', $play_url[1]);
							$play_url = "http://anime-fever.com/xem-phim/".$play_url[0];
							$html_link_play = $curl->get($play_url);
							$link_phim = explode('onjwplayer("',$html_link_play);
                            $link_phim = explode('",',$link_phim[1]);
                            $link_phim = base64_decode($link_phim[0]);
                            // $link_phim = explode(';proxy.link=', $html_link_play);
							//$link_phim = explode('&amp;', $link_phim[1]);
							//$link_phim = $link_phim[0];
							$play_embed[$i] = urldecode($link_phim);
							$name = explode('- Tập ', $html_link_play);
							$name = explode('</span>', $name[1]);
							$name = $name[0];
						}
						elseif ($_POST['webgrab'] == 'animefav') {
							$play_url = explode('phim/', $url_play[$i]);
							$play_url = explode('"', $play_url[1]);
							$play_url = "http://animefav.info/xem-phim/".$play_url[0];
							$html_link_play = $curl->get($play_url);
							$link_phim = explode('"proxy.link":"', $html_link_play);
							$link_phim = explode('"', $link_phim[1]);
							$link_phim = $link_phim[0];
							$play_embed[$i] = $link_phim;
							$name = explode('itemprop="title">Tập ', $html_link_play);
							$name = explode(' |', $name[1]);
							$name = $name[0];
						}
						elseif ($_POST['webgrab'] == 'animevn') {
							$play_url = explode('phim/', $url_play[$i]);
							$play_url = explode('"', $play_url[1]);
							$play_url = "http://www.animevn.biz/xem-phim/".$play_url[0];
							$html_link_play = $curl->get($play_url);
							$link_phim = explode('"proxy.link": "', $html_link_play);
							$link_phim = explode('",', $link_phim[1]);
							$link_phim = $link_phim[0];
							$play_embed[$i] = $link_phim;
							$name = explode('itemprop="title">Tập ', $html_link_play);
							$name = explode('</span>', $name[1]);
							$name = $name[0];
						}
						elseif ($_POST['webgrab'] == 'phim37') {
							$play_url = explode('phim/online/', $url_play[$i]);
							$play_url = explode('"', $play_url[1]);
							$play_url = "http://phim37.net/xem-phim/online/".$play_url[0];
							$html_link_play = xem_web($play_url);
							$link_phim = explode(';proxy.link=', $html_link_play);
							$link_phim = explode('&amp', $link_phim[1]);
							$link_phim = $link_phim[0];
							$play_embed[$i] = $link_phim;
							$name = explode(' Tap ', $html_link_play);
							$name = explode('</title>', $name[1]);
							$name = $name[0];
						}
						elseif ($_POST['webgrab'] == 'phimdao') {
							$play_url = explode('href="./xem-phim/', $url_play[$i]);
							$play_url = explode('"', $play_url[1]);
							$play_url = "http://phimdao.net/xem-phim/".$play_url[0];
							$html_link_play = xem_web($play_url);
							$link_phim = explode('proxy.link=', $html_link_play);
							$link_phim = explode('&', $link_phim[1]);
							$link_phim = $link_phim[0];
							$play_embed[$i] = $link_phim;
							$name = explode('Tập ', $html_link_play);
							$name = explode(' Sever', $name[1]);
							$name = $name[0];
						}elseif ($_POST['webgrab'] == 'phim1biz') {
							$play_url = explode('online/', $url_play[$i]);
							$play_url = explode('"', $play_url[1]);
							$play_url = "http://phim1.biz/xem-phim/online/".$play_url[0];
							$html_link_play = xem_web($play_url);
							$link_phim = explode('"proxy.link": "', $html_link_play);
							$link_phim = explode('",', $link_phim[1]);
							$link_phim = $link_phim[0];
							$play_embed[$i] = $link_phim;
							$name = explode('| Tập ', $html_link_play);
							$name = explode('</title>', $name[1]);
							$name = $name[0];
						}elseif ($_POST['webgrab'] == 'phimvang') {
							$play_url = explode('him/', $url_play[$i]);
							$play_url = explode('"', $play_url[1]);
							$play_url = "http://phim7.com/xem-phim/".$play_url[0];
							$html_link_play = xem_web($play_url);
							$link_phim = explode("{'link':'", $html_link_play);
							$link_phim = explode("'}", $link_phim[1]);
							$play_embed[$i] = $link_phim[0];
							$name = explode('class="waiting">', $url_play[$i]);
							$name = explode('</a>', $name[1]);
							$name = $name[0];
						}
						elseif ($_POST['webgrab'] == 'anime89') {
							$play_url = explode('phim/', $url_play[$i]);
							$play_url = explode('"', $play_url[1]);
							$play_url = "http://anime89.zapto.org/movie/xem-phim/".$play_url[0];
							$html_link_play = xem_web($play_url);
							$link_phim = explode('<iframe width="100%" height="100%" src="', $html_link_play);
							$link_phim = explode('"', $link_phim[1]);
							$play_embed[$i] = $link_phim[0];
							$name = explode('<font color="#777">Episode ', $url_play[$i]);
							$name = explode('</font></b>', $name[1]);
							$name = $name[0];
						}
						
                    ?>			
					<tr>
					<td class=fr width='20%'><b>Tập <input onclick="this.select();" type=text name=name[<?=$i?>] size=4 value="<?=$name?>" style="text-align:center;"></b></td>
					<td class='fr_2'> Link <input type=text name=url[<?=$i?>] size=60 value="<?=$play_embed[$i]?>">
					</td>
					</tr>
                    <?php
                    }
                    ?>
					<tr>
					<td class=fr colspan=2 align=center>
					<input type="hidden" name="episode_begin" value="<?=$episode_begin?>">
                    <input type="hidden" name="episode_end" value="<?=$episode_end?>">
					<input type=hidden name=ok value=Submit>
					<input type=submit name=submit class="sutm" value="Send">
					</td>
					</tr>
					</table>
					</form>
<?php
}
else {
	$actor			= $_POST['phim_dienvien'];
	$cat			= join_value($_POST['selectcat']);
	//$cat		 	= implode(',',$_POST['cat']);
	$new_film   	= $_POST['new_phim'];
	$name_real   	= $_POST['tienganh'];
	$trailer	   	= $_POST['trailer'];
	$info		  	= $_POST['phim_info'];
	$time		    = $_POST['phim_thoigian'];
	$year		   	= $_POST['phim_nam'];
	$director	    = $_POST['phim_daodien'];
	$country		= $_POST['country'];
	$tapphim		= $_POST['tapphim'];
	$tag			= $_POST['tagseo'];
	$bo_le			= $_POST['phimbole'];
	$t_singer   	= $actor;
	$imgBig         = $_POST['imgBig'];
	$area			= $_POST['nhasx'];
	// add film

	if ($new_film) {
		$new_film_img = $_POST['phim_imgz'];
		$film_id =  acp_quick_add_film2($new_film,$name_real,$trailer,$tapphim,$new_film_img,$imgBig,$actor,$year,$time,$area,$director,$cat,$info,$country,$file_type,$bo_le,$key,$des,$imgbn,$tag);
			}
	$t_film = $film_id;
	for ($i=$episode_begin;$i<=$episode_end;$i++){
		$t_url = $_POST['url'][$i];
		$t_name = $_POST['name'][$i];
		$t_sub = $_POST['sub'][$i];
		$t_message = $_POST['message'][$i];
		// server post
		if($_POST['server_post']==0) {
			$t_type = acp_type($t_url);
		}else {
			$t_type = intval($_POST['server_post']);
		}

		//lech sub
		if ($t_url && $t_name) {
		$mysql->query("INSERT INTO ".$tb_prefix."episode (episode_film,episode_url,episode_type,episode_name) VALUES ('".$t_film."','".$t_url."','".$t_type."','".$t_name."')");
		$mysql->query("UPDATE ".$tb_prefix."film SET film_date = '".NOW."' WHERE film_id = ".$t_film."");
		

		}

	}
	header("Location: index.php?act=clipvn");
}
?>
 </td>
              </tr>
            </table></td>
        </tr>
      </table></td>
  </tr>
</table>
</body>
</html>