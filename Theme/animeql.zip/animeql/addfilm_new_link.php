<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Content</title>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<?php
//include('start.php');
function htmltxt($document){
	$search = array('@<script[^>]*?>.*?</script>@si',  // Strip out javascript
				   '@<[\/\!]*?[^<>]*?>@si',            // Strip out HTML tags
				   '@<style[^>]*?>.*?</style>@siU',    // Strip style tags properly
				   '@<![\s\S]*?--[ \t\n\r]*>@'         // Strip multi-line comments including CDATA
	);
	$text = preg_replace($search, '', $document);
	return $text;
}
function xem_web($url) {
	$ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $url);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Googlebot/2.1 (+http://www.google.com/bot.html)');
  curl_setopt($ch, CURLOPT_HEADER, true );
  curl_setopt($ch, CURLOPT_REFERER, 'http://www.google.com');
  curl_setopt($ch, CURLOPT_ENCODING, 'gzip,deflate');
  curl_setopt($ch, CURLOPT_AUTOREFERER, true);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_TIMEOUT, 120);

		$result = curl_exec($ch);
		curl_close($ch);
		return $result;
}

function grabzzzzz($url) {
if (preg_match("#http://phim.clip.vn/watch/(.*?)/(.*?)#s",$url,$id_sr)){
    	$id 	= 	$id_sr[1];
		$id = explode(',', $id);
		$url	=	'http://clip.vn/embed/'.$id[1];		
	}
return $url;
}
if ($_POST['webgrab'] == 'clipvn') {
	$info_url_html = $curl->get($_POST['urlgrab']);
	$url_play = explode('<a href="http://phim.clip.vn/wa', $info_url_html);
	$total_play = count($url_play);
	$total_plays = $total_play-1;
}
elseif ($_POST['webgrab'] == 'phim8') {
	$info_url_html = xem_web($_POST['urlgrab']);
	$url_play_phim = explode('<a href="http://phim8.info/xem-phim/', $info_url_html);
	$url_play_phim = explode('" alt="Xem phim trực tuyến"', $url_play_phim[1]);
	$url_play_html_phim = 'http://phim8.info/xem-phim/'.$url_play_phim[0];
	$url_play_phim = xem_web($url_play_html_phim);
	$url_play = explode('<a href="xem-', $url_play_phim);
	$total_play = count($url_play);
	$total_plays = $total_play-1;
}
elseif ($_POST['webgrab'] == '24hphim') {
	$info_url_html = xem_web($_POST['urlgrab']);
	$url_play_phim = explode('<a href="http://24hphim.net/xem-phim', $info_url_html);
	$url_play_phim = explode('"', $url_play_phim[1]);
	$url_play_html_phim = 'http://24hphim.net/xem-phim'.$url_play_phim[0];
	$url_play_phim = xem_web($url_play_html_phim);
	$url_play = explode('href="http://24hphim.net/xem-', $url_play_phim);
	$total_play = count($url_play);
	$total_plays = $total_play-1;
}
elseif ($_POST['webgrab'] == 'phim7com') {
	$info_url_html = xem_web($_POST['urlgrab']);
	$url_play_phim = explode('<a href="/xem-phim/', $info_url_html);
	$url_play_phim = explode('"', $url_play_phim[1]);
	$url_play_html_phim = 'http://nuiphim.com/xem-phim-online'.$url_play_phim[0];
	$url_play_phim = xem_web($url_play_html_phim);
	$url_play = explode('<a href="http://nuiphim.com/xem-phim-', $url_play_phim);
	$total_play = count($url_play);
	$total_plays = $total_play-1;
}
elseif ($_POST['webgrab'] == 'nuiphimcom') {
	$info_url_html = $curl->get($_POST['urlgrab']);
	$url_play_phim = explode('<a href="http://nuiphim.com/xem-phim-online', $info_url_html);
	$url_play_phim = explode('"', $url_play_phim[1]);
	$url_play_html_phim = 'http://nuiphim.com/xem-phim-online'.$url_play_phim[0];
	$url_play_phim = xem_web($url_play_html_phim);
	$url_play = explode('<a href="http://nuiphim.com/xem-phim-', $url_play_phim);
	$total_play = count($url_play);
	$total_plays = $total_play-1;
}
elseif ($_POST['webgrab'] == 'anime-fever') {
	$info_url_html = $curl->get($_POST['urlgrab']);
	$url_play_phim = explode('href="http://anime-fever.com/xem-phim', $info_url_html);
	$url_play_phim = explode('"', $url_play_phim[1]);
	$url_play_html_phim = 'http://anime-fever.com/xem-phim'.$url_play_phim[0];
	$url_play_phim = xem_web($url_play_html_phim);
	$url_play = explode('<a href="http://anime-fever.com/xem-', $url_play_phim);
	$total_play = count($url_play);
	$total_plays = $total_play-1;
}
elseif ($_POST['webgrab'] == 'animefav') {
	$info_url_html = $curl->get($_POST['urlgrab']);
	$url_play_phim = explode('<a href="http://animefav.info/xem-phim', $info_url_html);
	$url_play_phim = explode('"', $url_play_phim[1]);
	$url_play_html_phim = 'http://animefav.info/xem-phim'.$url_play_phim[0];
	$url_play_phim = xem_web($url_play_html_phim);
	$url_play = explode('class="" href="http://animefav.info/xem-', $url_play_phim);
	$total_play = count($url_play);
	$total_plays = $total_play-1;
}
elseif ($_POST['webgrab'] == 'animevn') {
	$info_url_html = $curl->get($_POST['urlgrab']);
	$url_play_phim = explode('href=http://www.animevn.biz/xem-phim', $info_url_html);
	$url_play_phim = explode('>', $url_play_phim[1]);
	$url_play_html_phim = 'http://www.animevn.biz/xem-phim'.$url_play_phim[0];
	$url_play_phim = xem_web($url_play_html_phim);
	$url_play = explode('<a href="http://www.animevn.biz/xem-', $url_play_phim);
	$total_play = count($url_play);
	$total_plays = $total_play-1;
}
elseif ($_POST['webgrab'] == 'phim37') {
	$info_url_html = xem_web($_POST['urlgrab']);
	$url_play_phim = explode('"  href="http://phim37.net/xem-phim/online', $info_url_html);
	$url_play_phim = explode('"', $url_play_phim[1]);
	$url_play_html_phim = 'http://phim37.net/xem-phim/online'.$url_play_phim[0];
	$url_play_phim = xem_web($url_play_html_phim);
	$url_play = explode('href="http://phim37.net/xem-', $url_play_phim);
	$total_play = count($url_play);
	$total_plays = $total_play-1;
}
elseif ($_POST['webgrab'] == 'phimvang') {
	$info_url_html = xem_web($_POST['urlgrab']);
	$url_play_phim = explode('<p><a href="/xem-phim/', $info_url_html);
	$url_play_phim = explode('"', $url_play_phim[1]);
	$url_play_html_phim = 'http://phim7.com/xem-phim/'.$url_play_phim[0];
	$url_play_phim = xem_web($url_play_html_phim);
	$url_play = explode('<a href="/xem-p', $url_play_phim);
	$total_play = count($url_play);
	$total_plays = $total_play-1;
}
elseif ($_POST['webgrab'] == 'anime89') {
	$info_url_html = xem_web($_POST['urlgrab']);
	$url_play_phim = explode('<div class="thumbnail2"><a href="./xem-phim/', $info_url_html);
	$url_play_phim = explode('"', $url_play_phim[1]);
	$url_play_html_phim = 'http://anime89.zapto.org/movie/xem-phim/'.$url_play_phim[0];
	$url_play_phim = xem_web($url_play_html_phim);
	$url_play = explode('<a href="xem-', $url_play_phim);
	$total_play = count($url_play);
	$total_plays = $total_play-1;
}
?>
<?php
$begin = $_POST['episode_begin'];
$end = $_POST['episode_end'];
////BEGIN CHECK EPISODE
if(!is_numeric($begin) && !is_numeric($end)){
if ($_POST['webgrab'] == 'animevn') {
$episode_begin = 2;
}
else
{
$episode_begin = 1;
}
$episode_end = $total_plays;
}elseif(!is_numeric($begin) && !is_numeric($end)){
$episode_begin = 1;
$episode_end = 10;
}elseif(!is_numeric($begin)){
$episode_begin = $episode_end = $end;
}else{
$episode_begin = $begin; $episode_end = $end;
}
////END CHECK EPISODE
if (!$_POST['submit']) {
?>
<script>
var total = <?=$total_links?>;
<? for ($z=1; $z<=$total_sv; $z++) { ?>
    function check_local_<?=$z?>(status){
        for(i=1;i<=total;i++)
            document.getElementById("local_url_<?=$z?>_"+i).checked=status;
    }
<? } ?>
</script>
					<?php
 for ($i=$episode_begin;$i<=$episode_end;$i++) {
						if ($_POST['webgrab'] == 'clipvn') {
							$play_url = explode('tch/', $url_play[$i]);
							$play_url = explode('" title="', $play_url[1]);
							$name = explode('Tap', $url_play[$i]);
							$name = explode(',', $name[1]);
							$name = str_replace('Xem phim','',$name[0]);
							$play_url = $play_url[0];
							$play_embed[$i] = grabzzzzz('http://phim.clip.vn/watch/'.$play_url);
						}
						elseif ($_POST['webgrab'] == '24hphim') {
							$play_url = explode('phim-', $url_play[$i]);
							$play_url = explode('"', $play_url[1]);
							$play_url = 'http://24hphim.net/xem-phim-'.$play_url[0];
							$html_link_play = xem_web($play_url);
							$link_phim = explode('"proxy.link": "', $html_link_play);
							$link_phim = explode('",', $link_phim[1]);
							$link_phim = $link_phim[0];
							$play_embed[$i] = $link_phim;
							$name = explode('<h2 class="item last-child">Tập ', $html_link_play);
							$name = explode(' |', $name[1]);
							$name = $name[0];
						}
						
						elseif ($_POST['webgrab'] == 'nuiphimcom') {
							$play_url = explode('online/', $url_play[$i]);
							$play_url = explode('"', $play_url[1]);
							$play_url = "http://nuiphim.com/xem-phim-online/".$play_url[0];
							$html_link_play = xem_web($play_url);
							$link_phim = explode('proxy.link=', $html_link_play);
							$link_phim = explode('&', $link_phim[1]);
							$link_phim = $link_phim[0];
							$play_embed[$i] = $link_phim;
							$name = explode('TẬP ', $html_link_play);
							$name = explode('">', $name[1]);
							$name = $name[0];
						}
						elseif ($_POST['webgrab'] == 'anime-fever') {
							$play_url = explode('phim/', $url_play[$i]);
							$play_url = explode('"', $play_url[1]);
							$play_url = "http://anime-fever.com/xem-phim/".$play_url[0];
							$html_link_play = $curl->get($play_url);
							$link_phim = explode('onjwplayer("',$html_link_play);
                                                        $link_phim = explode('",',$link_phim[1]);
                                                        $link_phim = base64_decode($link_phim[0]);
                                                       // $link_phim = explode(';proxy.link=', $html_link_play);
							//$link_phim = explode('&amp;', $link_phim[1]);
							//$link_phim = $link_phim[0];
							$play_embed[$i] = urldecode($link_phim);
							$name = explode('- Tập ', $html_link_play);
							$name = explode('</span>', $name[1]);
							$name = $name[0];
						}
						elseif ($_POST['webgrab'] == 'animefav') {
							$play_url = explode('phim/', $url_play[$i]);
							$play_url = explode('"', $play_url[1]);
							$play_url = "http://animefav.info/xem-phim/".$play_url[0];
							$html_link_play = $curl->get($play_url);
							$link_phim = explode('"proxy.link":"', $html_link_play);
							$link_phim = explode('"', $link_phim[1]);
							$link_phim = $link_phim[0];
							$play_embed[$i] = $link_phim;
							$name = explode('itemprop="title">Tập ', $html_link_play);
							$name = explode(' |', $name[1]);
							$name = $name[0];
						}
						elseif ($_POST['webgrab'] == 'animevn') {
							$play_url = explode('phim/', $url_play[$i]);
							$play_url = explode('"', $play_url[1]);
							$play_url = "http://www.animevn.biz/xem-phim/".$play_url[0];
							$html_link_play = $curl->get($play_url);
							$link_phim = explode('"proxy.link": "', $html_link_play);
							$link_phim = explode('",', $link_phim[1]);
							$link_phim = $link_phim[0];
							$play_embed[$i] = $link_phim;
							$name = explode('itemprop="title">Tập ', $html_link_play);
							$name = explode('</span>', $name[1]);
							$name = $name[0];
						}
						elseif ($_POST['webgrab'] == 'phim37') {
							$play_url = explode('phim/online/', $url_play[$i]);
							$play_url = explode('"', $play_url[1]);
							$play_url = "http://phim37.net/xem-phim/online/".$play_url[0];
							$html_link_play = xem_web($play_url);
							$link_phim = explode(';proxy.link=', $html_link_play);
							$link_phim = explode('&amp', $link_phim[1]);
							$link_phim = $link_phim[0];
							$play_embed[$i] = $link_phim;
							$name = explode(' Tap ', $html_link_play);
							$name = explode('</title>', $name[1]);
							$name = $name[0];
						}
						
						elseif ($_POST['webgrab'] == 'phimvang') {
							$play_url = explode('him/', $url_play[$i]);
							$play_url = explode('"', $play_url[1]);
							$play_url = "http://phim7.com/xem-phim/".$play_url[0];
							$html_link_play = xem_web($play_url);
							$link_phim = explode("{'link':'", $html_link_play);
							$link_phim = explode("'}", $link_phim[1]);
							$play_embed[$i] = $link_phim[0];
							$name = explode('class="waiting">', $url_play[$i]);
							$name = explode('</a>', $name[1]);
							$name = $name[0];
						}
						elseif ($_POST['webgrab'] == 'anime89') {
							$play_url = explode('phim/', $url_play[$i]);
							$play_url = explode('"', $play_url[1]);
							$play_url = "http://anime89.zapto.org/movie/xem-phim/".$play_url[0];
							$html_link_play = xem_web($play_url);
							$link_phim = explode('<iframe width="100%" height="100%" src="', $html_link_play);
							$link_phim = explode('"', $link_phim[1]);
							$play_embed[$i] = $link_phim[0];
							$name = explode('<font color="#777">Episode ', $url_play[$i]);
							$name = explode('</font></b>', $name[1]);
							$name = $name[0];
						}
						
                    ?>			
<?=$name?>||<?=$play_embed[$i]?><br>
                    <?php
                    }
                    ?>
<?php
}
?>
</html>