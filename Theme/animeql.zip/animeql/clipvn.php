<table class="border" cellpadding="2" cellspacing="0" width="50%">
<tr>
        <td class="title" align="center" colspan="2">
          Thêm Phim Nhiều Website
        </td>
    </tr>
<form method="post" action="./?act=addmulti">
						<tr>
						<td class="fr" align="center" width="100%">
                                <label>Website:</label>
                                <select name="webgrab">
				<option value="anime-fever">anime-fever.com</option>				        
                                    <option value="animevn">animevn.biz</option>
                                    <option value="animefav">animefav.info</option>
									<option value="anime89">anime89.zapto.org</option>
									<option value="phimvang">PhimVang.Org</option>
									<option value="phimhayhot">PhimHayHot.Com</option>
									<option value="phimletvn">Phim.Let.Vn</option>
									<option value="phim1biz">Phim1.Biz</option>
									<option value="phimkk">phimkk.com</option>
									<option value="phimtrangcom">PhimTrang.Com</option>
									<option value="clipvn">Phim.Clip.Vn</option>
									<option value="Phimhdhay">Phimhdhay.vn</option>
									<option value="phimphim">Phimphim.Com</option>
									<option value="phim8">Phim8.Info</option>
									<option value="phim85">phim85.com</option>
									<option value="themxua">Themxua.Com</option>
									<option value="nuiphimcom">NuiPhim.Com</option>
									<option value="phimdao">PhimDao.Net</option>
									<option value="24hphim">24hphim.net</option>
									<option value="phim37">phim37.net</option>
									<option value="anime-fever-test">anime-fever-test</option>
								
								</select>    
						</td>
						</tr>
	<tr>
        <td class="fr" align="center" width="100%">
           Link Phim : <input class="flat" size="60" name="urlgrab" value="Điền link vào đây" onclick="this.select()" maxlength="250">
        </td>

    </tr>
 						<tr>
        <td class="fr" align="center" width="100%">
							<label style="color:#777;padding-top:10px;"><span class="required_marker">*</span> Điền link info phim</label><br />
							<span onmouseout="this.className='mb_btn1'" onmouseover="this.className='mb_btn1_hover'" class="mb_btn1">
								<button value="Submit" name="ok" type="submit">Gửi đi</button>
							</span>
						 </td>

    </tr>
</form>
</table>