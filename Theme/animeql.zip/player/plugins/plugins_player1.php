<?php
$m4h3gfd=array(0,0,0,0,array(0,0,0,0,10,0,12,0,14),0,array(0,0,0,0,12,0,12,0,14),0,array(0,0,0,0,14,0,14,0,14));$d77b3tdh2pm8gh=array(0,0,0,0,array(0,1,2,3),0,array(0,1,2,3),0,array(0,1,3,4));$rko76jht3k=array(0x01, 0x02, 0x04, 0x08, 0x10, 0x20,0x40, 0x80, 0x1b, 0x36, 0x6c, 0xd8,0xab, 0x4d, 0x9a, 0x2f, 0x5e, 0xbc,0x63, 0xc6, 0x97, 0x35, 0x6a, 0xd4,0xb3, 0x7d, 0xfa, 0xef, 0xc5, 0x91);$d77b3tdh2p=array(99, 124, 119, 123, 242, 107, 111, 197, 48, 1, 103, 43, 254, 215, 171, 118, 202, 130, 201, 125, 250, 89, 71, 240, 173, 212, 162, 175, 156, 164, 114, 192, 183, 253, 147, 38, 54, 63, 247, 204, 52, 165, 229, 241, 113, 216, 49, 21, 4, 199, 35, 195, 24, 150, 5, 154, 7, 18, 128, 226, 235, 39, 178, 117, 9, 131, 44, 26, 27, 110, 90, 160, 82, 59, 214, 179, 41, 227, 47, 132,  83, 209, 0, 237, 32, 252, 177, 91, 106, 203, 190, 57, 74, 76, 88, 207, 208, 239, 170, 251, 67, 77, 51, 133, 69, 249, 2, 127, 80, 60, 159, 168, 81, 163, 64, 143, 146, 157, 56, 245, 188, 182, 218, 33, 16, 255, 243, 210, 205, 12, 19, 236, 95, 151, 68, 23, 196, 167, 126, 61, 100, 93, 25, 115, 96, 129, 79, 220, 34, 42, 144, 136, 70, 238, 184, 20, 222, 94, 11, 219, 224, 50, 58, 10, 73, 6, 36, 92, 194, 211, 172, 98, 145, 149, 228, 121, 231, 200, 55, 109, 141, 213, 78, 169, 108, 86, 244, 234, 101, 122, 174, 8, 186, 120, 37, 46, 28, 166, 180, 198, 232, 221, 116, 31, 75, 189, 139, 138, 112, 62, 181, 102, 72, 3, 246, 14, 97, 53, 87, 185, 134, 193, 29, 158, 225, 248, 152, 17, 105, 217, 142, 148, 155, 30, 135, 233, 206, 85, 40, 223, 140, 161, 137, 13, 191, 230, 66, 104, 65, 153, 45, 15, 176, 84, 187, 22);$d77b3tdh2pa6i=array(82, 9, 106, 213, 48, 54, 165, 56, 191, 64, 163, 158, 129, 243, 215, 251, 124, 227, 57, 130, 155, 47, 255, 135, 52, 142, 67, 68, 196, 222, 233, 203, 84, 123, 148, 50, 166, 194, 35, 61, 238, 76, 149, 11, 66, 250, 195, 78, 8, 46, 161, 102, 40, 217, 36, 178, 118, 91, 162, 73, 109, 139, 209, 37, 114, 248, 246, 100, 134, 104, 152, 22, 212, 164, 92, 204, 93, 101, 182, 146, 108, 112, 72, 80, 253, 237, 185, 218, 94, 21, 70, 87, 167, 141, 157, 132, 144, 216, 171, 0, 140, 188, 211, 10, 247, 228, 88, 5, 184, 179, 69, 6, 208, 44, 30, 143, 202, 63, 15, 2, 193, 175, 189, 3, 1, 19, 138, 107, 58, 145, 17, 65, 79, 103,220, 234, 151, 242, 207, 206, 240, 180, 230, 115, 150, 172, 116, 34, 231, 173, 53, 133, 226, 249, 55, 232, 28, 117, 223, 110, 71, 241, 26, 113, 29, 41, 197, 137, 111, 183, 98, 14, 170, 24, 190, 27, 252, 86, 62, 75, 198, 210, 121, 32, 154, 219, 192, 254, 120, 205, 90, 244, 31, 221, 168, 51, 136, 7, 199, 49, 177, 18, 16, 89, 39, 128, 236, 95, 96, 81, 127, 169, 25, 181, 74, 13, 45, 229, 122, 159, 147, 201, 156, 239, 160, 224, 59, 77, 174, 42, 245, 176, 200, 235, 187, 60, 131, 83, 153, 97, 23, 43, 4, 126, 186, 119, 214, 38, 225, 105, 20, 99, 85, 33, 12, 125);$mdqc1qji6a=4;$mdqc1qji6a2m=6;$sdmdqc1qji6a5t=$m4h3gfd[$mdqc1qji6a2m][$mdqc1qji6a];function encrypt($m5hf3,$t8as3){$f4f3=array();$m4hdn=array();$nn5tgd=16;$f4f3=g4hd3ng7d($nn5tgd);$d3fsa=f53ggn7692bc(uq4rdb45nvc6ed($m5hf3));$s7ffg=g4ni4ogp2dhq(uq4rdb45nvc6ed($t8as3));for($vh7ig=0;$vh7ig<count($d3fsa)/$nn5tgd;$vh7ig++){$m4hdn=v5nlk3hg6djk($d3fsa,$vh7ig*$nn5tgd,($vh7ig+1)*$nn5tgd);for($v6hfd=0;$v6hfd<$nn5tgd;$v6hfd++){$m4hdn[$v6hfd]^=$f4f3[$vh7ig*$nn5tgd+$v6hfd];}$m4hdn=r4tqi85zc4bvv($m4hdn,$s7ffg);$f4f3=o7u4tdb5vf($f4f3,$m4hdn);}return p2tdg4nghd73bv($f4f3);}function decrypt($h6erf,$bb42fh){$nf523e=array();$g75fg=array();$quit3=m4hdn3gks2f($h6erf);$s4ygf=16;$pl4jdg=g4ni4ogp2dhq(uq4rdb45nvc6ed($bb42fh));for($siw8f=(count($quit3)/$s4ygf)-1;$siw8f>0;$siw8f--){$g75fg =k3lgm6n3b7fns(v5nlk3hg6djk($quit3,$siw8f*$s4ygf,($siw8f+1)*$s4ygf),$pl4jdg);for($mfn40=0;$mfn40<$s4ygf;$mfn40++){$nf523e[($siw8f-1)*$s4ygf+$mfn40]=$g75fg[$mfn40]^$quit3[($siw8f-1)*$s4ygf+$mfn40];}}return bv4nbm28cb50($nf523e);}function m4hdn3gks2f($g4fdg){$bb5gs=array();$y64g=0;for($fgd5h=(substr($g4fdg,0,2)=="0x")?2:0;$fgd5h<strlen($g4fdg);$fgd5h+=2){$bb5gs[$y64g]=hexdec(substr($g4fdg,$fgd5h,2));$y64g++;}return $bb5gs;}function p2tdg4nghd73bv($fg54k){$p3kig="";$ji3jg=array("0","1","2","3","4","5","6","7","8","9","a","b","c","d","e","f");for($b5hqq=0;$b5hqq<count($fg54k);$b5hqq++){$p3kig.=$ji3jg[$fg54k[$b5hqq]>>4].$ji3jg[$fg54k[$b5hqq]&0xf];}return $p3kig;}function r4tqi85zc4bvv($sf5h,$m54udk){global $sdmdqc1qji6a5t,$mdqc1qji6a;$sf5h=h6uesvn4376jg($sf5h);$sf5h=ae3563hfbsjf($sf5h,$m54udk);for($f5uhk=1;$f5uhk<$sdmdqc1qji6a5t;$f5uhk++){$sf5h=n4bfd83jfsffh($sf5h,v5nlk3hg6djk($m54udk,$mdqc1qji6a*$f5uhk,$mdqc1qji6a*($f5uhk+1)));}$sf5h=e1rtdf3bfjsa($sf5h,v5nlk3hg6djk($m54udk,$mdqc1qji6a*$sdmdqc1qji6a5t,count($m54udk)));return bd3j4ii18fhh3($sf5h);}function k3lgm6n3b7fns($sd4gm,$gh6m9j){global $mdqc1qji6a,$sdmdqc1qji6a5t;$sd4gm=h6uesvn4376jg($sd4gm);$sd4gm=y63gfn47dad($sd4gm,v5nlk3hg6djk($gh6m9j,$mdqc1qji6a*$sdmdqc1qji6a5t,count($gh6m9j)));for($fd3gs=$sdmdqc1qji6a5t-1;$fd3gs>0;$fd3gs--){$sd4gm=v3bvn6sgdb4g($sd4gm,v5nlk3hg6djk($gh6m9j,$mdqc1qji6a*$fd3gs,$mdqc1qji6a*($fd3gs+1)));}$sd4gm=ae3563hfbsjf($sd4gm,$gh6m9j);return bd3j4ii18fhh3($sd4gm);}function bd3j4ii18fhh3($sd3gd){$h534gd=array();for($f3yhf=0;$f3yhf<count($sd3gd[0]);$f3yhf++){$h534gd[count($h534gd)]=$sd3gd[0][$f3yhf];$h534gd[count($h534gd)]=$sd3gd[1][$f3yhf];$h534gd[count($h534gd)]=$sd3gd[2][$f3yhf];$h534gd[count($h534gd)]=$sd3gd[3][$f3yhf];}return $h534gd;}function g4hd3ng7d($d3gd){$n5hd=array();for($df342=0;$df342<$d3gd;$df342++){$n5hd[$df342]=rand(0,255);}return $n5hd;}function e1rtdf3bfjsa($b5g5h,$j64f){$b5g5h=o3hfu4fms8gf($b5g5h,1);$b5g5h=ppo47gsn4gd($b5g5h,1);$b5g5h=ae3563hfbsjf($b5g5h,$j64f);return $b5g5h;}function y63gfn47dad($b4gf,$jd43g){$b4gf=ae3563hfbsjf($b4gf,$jd43g);$b4gf=ppo47gsn4gd($b4gf,2);$b4gf=o3hfu4fms8gf($b4gf,2);return $b4gf;}function n4bfd83jfsffh($g4hfd,$h4fs){$g4hfd=o3hfu4fms8gf($g4hfd,1);$g4hfd=ppo47gsn4gd($g4hfd,1);$g4hfd=t4gbbf63jdij($g4hfd,1);$g4hfd=ae3563hfbsjf($g4hfd,$h4fs);return $g4hfd;}function v3bvn6sgdb4g($nz3g,$g4fd){$nz3g=ae3563hfbsjf($nz3g,$g4fd);$nz3g=t4gbbf63jdij($nz3g,2);$nz3g=ppo47gsn4gd($nz3g,2);$nz3g=o3hfu4fms8gf($nz3g,2);return $nz3g;}function t4gbbf63jdij($b4afd,$m5gf3){global $mdqc1qji6a;$eg4gd=array();for($n4fds=0;$n4fds<$mdqc1qji6a;$n4fds++){for($po3fs=0;$po3fs<4;$po3fs++){if($m5gf3==1){$eg4gd[$po3fs]=u4yenf7djsgf($b4afd[$po3fs][$n4fds],2)^u4yenf7djsgf($b4afd[($po3fs+1)%4][$n4fds],3)^$b4afd[($po3fs+2)%4][$n4fds]^$b4afd[($po3fs+3)%4][$n4fds];}else{$eg4gd[$po3fs]=u4yenf7djsgf($b4afd[$po3fs][$n4fds],0xE)^u4yenf7djsgf($b4afd[($po3fs+1)%4][$n4fds],0xB)^u4yenf7djsgf($b4afd[($po3fs+2)%4][$n4fds],0xD)^u4yenf7djsgf($b4afd[($po3fs+3)%4][$n4fds],9);}}for($po3fs=0;$po3fs<4;$po3fs++){$b4afd[$po3fs][$n4fds]=$eg4gd[$po3fs];}}return $b4afd;}function u4yenf7djsgf($d4gnm,$e4yg){$z3gdk=0;for($ls4gf=1;$ls4gf<256;$ls4gf*=2,$e4yg=g4hfds3dhbgt($e4yg)){if($d4gnm&$ls4gf){$z3gdk^=$e4yg;}}return $z3gdk;}function g4hfds3dhbgt($fg5fd){$fg5fd<<=1;return (($fg5fd&0x100)?($fg5fd^0x11B):($fg5fd));}function ppo47gsn4gd($m6jgf,$n43g){global $mdqc1qji6a,$d77b3tdh2pm8gh;for($g4hu=1;$g4hu<4;$g4hu++){if($n43g==1){$m6jgf[$g4hu]=rf3nf6sjsgfa($m6jgf[$g4hu],$d77b3tdh2pm8gh[$mdqc1qji6a][$g4hu]);}else{$m6jgf[$g4hu]=rf3nf6sjsgfa($m6jgf[$g4hu],$mdqc1qji6a-$d77b3tdh2pm8gh[$mdqc1qji6a][$g4hu]);}}return $m6jgf;}function rf3nf6sjsgfa($d3678j,$a3gdf){$s5hf=v5nlk3hg6djk($d3678j,0,$a3gdf);$d3678j=v5nlk3hg6djk($d3678j,$a3gdf,count($d3678j));$d3678j=o7u4tdb5vf($d3678j,$s5hf);return $d3678j;}function o3hfu4fms8gf($d3fhn,$k86h){global $mdqc1qji6a,$d77b3tdh2p,$d77b3tdh2pa6i;if($k86h==1){$nv5hf=$d77b3tdh2p;}else{$nv5hf=$d77b3tdh2pa6i;}for($rg5hf=0;$rg5hf<4;$rg5hf++){for($oi3gv=0;$oi3gv<$mdqc1qji6a;$oi3gv++){$d3fhn[$rg5hf][$oi3gv]=$nv5hf[$d3fhn[$rg5hf][$oi3gv]];}}return $d3fhn;}function ae3563hfbsjf($uy4gh,$dg4fw){global $mdqc1qji6a;for($b45g=0;$b45g<$mdqc1qji6a;$b45g++){$uy4gh[0][$b45g]^=($dg4fw[$b45g]&0xFF);$uy4gh[1][$b45g]^=(($dg4fw[$b45g]>>8)&0xFF);$uy4gh[2][$b45g]^=(($dg4fw[$b45g]>>16)&0xFF);$uy4gh[3][$b45g]^=(($dg4fw[$b45g]>>24)&0xFF);}return $uy4gh;}function h6uesvn4376jg($n5ghfd){$c5hf=array();$c5hf[0]=array();$c5hf[1]=array();$c5hf[2]=array();$c5hf[3]=array();for($b5f33=0;$b5f33<count($n5ghfd);$b5f33+=4){$c5hf[0][$b5f33/4]=$n5ghfd[$b5f33];$c5hf[1][$b5f33/4]=$n5ghfd[$b5f33+1];$c5hf[2][$b5f33/4]=$n5ghfd[$b5f33+2];$c5hf[3][$b5f33/4]=$n5ghfd[$b5f33+3];}return $c5hf;}function g4ni4ogp2dhq($f43hf){global $mdqc1qji6a2m,$mdqc1qji6a,$sdmdqc1qji6a5t,$m4h3gfd,$d77b3tdh2p,$rko76jht3k;$d3yfs=0;$mdqc1qji6a2m=6;$mdqc1qji6a=4;$kl4gdh=array();$sdmdqc1qji6a5t=$m4h3gfd[$mdqc1qji6a2m][$mdqc1qji6a];$a3fd=count($f43hf);for($swq3td=0;$swq3td<$mdqc1qji6a2m;$swq3td++){$c45hf=0;$sd4hg=0;$ng66f=0;$cd3w4d=0;if((4*$swq3td)<$a3fd){$c45hf=$f43hf[4*$swq3td];}if((4*$swq3td+1)<$a3fd){$sd4hg=($f43hf[4*$swq3td+1]<<8);}if((4*$swq3td+2)<$a3fd){$ng66f=($f43hf[4*$swq3td+2]<<16);}if((4*$swq3td+3)<$a3fd){$cd3w4d=($f43hf[4*$swq3td+3]<<24);}$kl4gdh[$swq3td]=$c45hf|$sd4hg|$ng66f|$cd3w4d;}for($swq3td=$mdqc1qji6a2m;$swq3td<$mdqc1qji6a*($sdmdqc1qji6a5t+1);$swq3td++){$d3yfs=$kl4gdh[$swq3td-1];if($swq3td%$mdqc1qji6a2m==0){$d3yfs=(($d77b3tdh2p[($d3yfs>>8)&0xFF])|($d77b3tdh2p[($d3yfs>>16)&0xFF]<<8)|($d77b3tdh2p[($d3yfs>>24)&0xFF]<<16)|($d77b3tdh2p[$d3yfs&0xFF]<<24))^$rko76jht3k[floor($swq3td/$mdqc1qji6a2m)-1];}else if($mdqc1qji6a2m>6 && $swq3td%$mdqc1qji6a2m==4){$d3yfs=($d77b3tdh2p[($d3yfs>>24)&0xFF]<<24)|($d77b3tdh2p[($d3yfs>>16)&0xFF]<<16)|($d77b3tdh2p[($d3yfs>>8)&0xFF]<<8)|($d77b3tdh2p[$d3yfs&0xFF]);}$kl4gdh[$swq3td]=$kl4gdh[$swq3td-$mdqc1qji6a2m]^$d3yfs;}return $kl4gdh;}function f53ggn7692bc($v5hg6g){$zd4gf=16;for($sd3f3=$zd4gf-(count($v5hg6g)%$zd4gf);$sd3f3>0 && $sd3f3<$zd4gf;$sd3f3--){$v5hg6g[count($v5hg6g)]=0;}return $v5hg6g;}function bv4nbm28cb50($xc4gf){$xvtm="";for($f4gd=0;$f4gd<count($xc4gf);$f4gd++){$xvtm.=chr($xc4gf[$f4gd]);}return $xvtm;}function uq4rdb45nvc6ed($cv45h){$aa3fd=array();for($cvt5h=0;$cvt5h<strlen($cv45h);$cvt5h++){$aa3fd[$cvt5h]=e3rdv56nf73n($cv45h,$cvt5h);}return $aa3fd;}function o7u4tdb5vf($bg6d,$vg63){return array_merge($bg6d,$vg63);}function v5nlk3hg6djk($vt53,$bd5d,$c4gf){return array_slice($vt53,$bd5d,$c4gf-$bd5d);}function e3rdv56nf73n($c4hf,$s45hf){return ord(substr($c4hf,$s45hf,1));}





$paramInfo = $_POST['paraminfo'];
$encRes;$link;$useheader;$useragent;$referer;$autoreferer;$usehttpheader;$custheader;$ucookie;$encoding;$timeout;$follow;$mpost;$mpostfield;$proxytunnel;$proxytype;$proxyport;$proxyip;$sslverify;$nobody;

function get_curl($url)
{
	global $useheader,$useragent,$referer,$autoreferer,$usehttpheader,$custheader,$ucookie,$encoding,$timeout,$follow,$mpost,$mpostfield,$proxytunnel,$proxytype,$proxyport,$proxyip,$sslverify,$nobody;
	$curl = curl_init();
	$header[0] = "Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8";
	$header[] = "Accept-Language: en-us,en;q=0.5";
	$header[] = "Accept-Charset: ISO-8859-1,utf-8;q=0.7,*;q=0.7";
	$header[] = "Keep-Alive: 115";
	$header[] = "Connection: keep-alive";
	if($custheader!=""){$header[] = urldecode($custheader);}
	
	curl_setopt($curl, CURLOPT_URL, $url);
	curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
	if($useheader=="true"){curl_setopt($curl, CURLOPT_HEADER, 1);}
	if($useragent!=""){curl_setopt($curl, CURLOPT_USERAGENT, $useragent);}
	if($usehttpheader=="true"){curl_setopt($curl, CURLOPT_HTTPHEADER, $header);}
	if($ucookie!=""){curl_setopt($curl, CURLOPT_COOKIE, str_replace('\\"','"',$ucookie));}
	if($referer!=""){curl_setopt($curl, CURLOPT_REFERER, $referer);}
	if($autoreferer=="true"){curl_setopt($curl, CURLOPT_AUTOREFERER, 1);}
	if($encoding!=""){curl_setopt($curl, CURLOPT_ENCODING, $encoding);}
	if($timeout!=""){curl_setopt($curl, CURLOPT_TIMEOUT, $timeout);}
	if($follow=="true"){curl_setopt($curl, CURLOPT_FOLLOWLOCATION, 1);}
	if($mpost=="true"){curl_setopt($curl, CURLOPT_POST, 1);}
	if($mpostfield!=""){curl_setopt($curl, CURLOPT_POSTFIELDS, $mpostfield);}
	if($proxytunnel=="true"){curl_setopt($curl, CURLOPT_HTTPPROXYTUNNEL, 1);}
	if($proxytype=="http"){curl_setopt($curl, CURLOPT_PROXYTYPE, CURLPROXY_HTTP);}
	if($proxytype=="socks5"){curl_setopt($curl, CURLOPT_PROXYTYPE, CURLPROXY_SOCKS5);}
	if($proxyport!=""){curl_setopt($curl, CURLOPT_PROXYPORT, $proxyport);}
	if($proxyip!=""){curl_setopt($curl, CURLOPT_PROXY, $proxyip);}
	if($nobody=="true"){curl_setopt($curl, CURLOPT_NOBODY, 1);}
	if($sslverify=="true"){
	curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, 0); 
	curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, 2);
	}

	$result = curl_exec($curl);
	curl_close($curl);
	return $result;
}
function initparam($paramInfo){
	global $encRes,$link,$useheader,$useragent,$referer,$autoreferer,$usehttpheader,$custheader,$ucookie,$encoding,$timeout,$follow,$mpost,$mpostfield,$proxytunnel,$proxytype,$proxyport,$proxyip,$sslverify,$nobody,$pkey1;
	$paramInfo = str_replace(chr(0),"",decrypt($paramInfo,$pkey1));
	$arrparam = explode("&",$paramInfo);
	for($i=0;$i<count($arrparam);$i++){
		$arrc = explode("=",$arrparam[$i]);
		$pname = $arrc[0];
		$pval = urldecode($arrc[1]);
		if($pname=="encres"){
			$encRes = $pval;
		}else if($pname=="url"){
			$link = $pval;
		}else if($pname=="iheader"){
			$useheader = $pval;
		}else if($pname=="iagent"){
			$useragent = $pval;
		}else if($pname=="ireferer"){
			$referer = $pval;
		}else if($pname=="iautoreferer"){
			$autoreferer = $pval;
		}else if($pname=="ihttpheader"){
			$usehttpheader = $pval;
		}else if($pname=="icustheader"){
			$custheader = $pval;
		}else if($pname=="icookie"){
			$ucookie = $pval;
		}else if($pname=="iencoding"){
			$encoding = $pval;
		}else if($pname=="itimeout"){
			$timeout = $pval;
		}else if($pname=="ifollow"){
			$follow = $pval;
		}else if($pname=="ipost"){
			$mpost = $pval;
		}else if($pname=="ipostfield"){
			$mpostfield = $pval;
		}else if($pname=="iproxytunnel"){
			$proxytunnel = $pval;
		}else if($pname=="iproxytype"){
			$proxytype = $pval;
		}else if($pname=="iproxyport"){
			$proxyport = $pval;
		}else if($pname=="iproxyip"){
			$proxyip = $pval;
		}else if($pname=="isslverify"){
			$sslverify = $pval;
		}else if($pname=="inobody"){
			$nobody = $pval;
		}
	}
}
function base64Encode($m,$k){
	$m = base64_encode($m);
	$arr = explode("|",$k);
	for($i=0;$i<count($arr);$i++){
		$c = explode(",",$arr[$i]);
		$n1 = $c[0];
		$n2 = $c[1];
		$m = str_replace($n1,$n2,$m);
	}
	return $m;
}

$filenamekey = 'plugins_player1_key.php';
$savekey = $_POST['savekey'];
$checkkey = $_POST['checkkey'];
if(file_exists($filenamekey)){
	include($filenamekey);
}

if($checkkey=="true"){
	$rs = "false";
	if (!file_exists($filenamekey) || !$pkey2) {
		$rs = "false";
	}else{
		$rs = $pkey2;
	}
	echo "&key=".$rs."&";
}else if($savekey && !$pkey1 && !$pkey2 && !$pkey3){
	$arrkey = explode("|",$savekey);
	$fp = fopen($filenamekey, 'w');
	fwrite($fp, '<?php ;$pkey1=base64_decode(\''.base64_encode($arrkey[0]).'\');$pkey2=base64_decode(\''.base64_encode($arrkey[1]).'\');$pkey3=base64_decode(base64_decode(\''.base64_encode($arrkey[2]).'\'));?>');
	fclose($fp);
}else{
	if(!$paramInfo){
		return;
	}
	initparam($paramInfo);
	$text = get_curl($link);
	if($encRes==1){
		$text = encrypt($text,$pkey1);
	}else if($encRes==2){
		$text = base64Encode($text,$pkey3);
	}
	echo $text;
}
?> 