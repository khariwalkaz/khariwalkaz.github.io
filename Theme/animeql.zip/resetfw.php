<?php
//if(file_exists('../.htaccess')) unlink('../.htaccess');
//if(file_exists('../baan.log')) unlink('../baan.log');
?>