<html>
<head>
	<title>Firewall</title>
	<meta name='Robots' content='Index,Follow'>
	<meta name='Distribution' content='Global'>
	<meta name='MSSmartTagsPreventParsing' content='True'>
	<meta http-equiv='content-type' content='text/html; charset=utf-8'>
	<meta http-equiv='pragma' content='no-cache'>
	<meta http-equiv='expires' content='-1'>
	<meta http-equiv='cache-control' content='no-cache,must-revalidate,no-store'>
	<meta http-equiv='imagetoolbar' content='no'>
</head>

<style>
body {
	background: #ffffff; color: #003366; padding: 20; text-align: center; font-size: 11pt; font-family: Tahoma, Arial, Verdana;
	background: url(http://face.cuatoi.net/images/firewall/firewall.jpg);
}
#wrapper {
	width: 550; margin: 100 auto; text-align: center;
}
table, tr, td {
	color: #003366; margin: 1; padding: 10;
}
.notice {
	color: #ff3300; font-style: bold; font-weight: bold; font-size: 14pt;
}
.notice1 {
	color: #ff3300; font-style: bold; font-weight: bold; font-size: 12pt;
}
a:link, a:visited, a:active {
	color: #2b5c8d; position: relative; text-decoration: none; font-weight: bold; font-size: 10pt;
}
a:hover { 
	color: #c6d9ec; position: relative; text-decoration: none; font-weight: bold; font-size: 10pt;
}
.entry {
	color: #2b5c8d;padding: 5 10; text-align: justify; line-height: 1.4em; width: 350;
}
#content {
	float: left; width: 550; height: 300; background: url(http://face.cuatoi.net/images/firewall/headshoot.jpg) #ffffff no-repeat top center;
}
</style>

<body scroll='no'>
<div id='wrapper'>

<table border='0'>
<tr> 
<td>
	<div id='content'>
	<hr noshade='noshade' size='1' width='390' align='left'>
		<font class='notice'>Thông báo!</font><br><br>
		<div class='entry'><font class='notice1'>IP <!--#echo var="REMOTE_ADDR" --></font><br>của bạn đã bị head shoot vì request quá nhiều tới server.</div><br>
		<font class='notice1'>Đang đá khỏi website!</font><br>
		<form name=loading>
      <p align=center><INpUT 
      style="BORDER-RIGHT: medium none; BORDER-TOp: medium none; BORDER-LEFT: medium none; COLOR: blue; BORDER-BOTTOM: medium none; BACKGROUND-COLOR: #FCFCFC; TEXT-ALIGN: center" 
      size=47 name=percent><br /></font><input 
      style="PADDING-RIGHT: 0px; pADDING-LEFT: 0px; font-WEIGHT: bolder; PADDING-BOTTOM: 0px; COLOR: blue; BORDER-TOP-STYLE: none; pADDING-TOP: 0px; font-FAMILY: Arial; BORDER-RIGHT-STYLE: none; BORDER-LEFT-STYLE: none; BACKGROUND-COLOR: #FCFCFC; BORDER-BOTTOM-STYLE: none" 
      size=45 name=chart><br /><b>
	<hr noshade='noshade' size='1' width='390' align='left'>
	</div>
</td>
</tr>
</table>

<embed src='http://face.cuatoi.net/images/firewall/alarm.swf' width='1' height='1' type='application/x-shockwave-flash' quality='normal' menu='false' wmode='transparent'>
</div>
      <script> 
var bar=0 
var line="||" 
var amount="||" 
count() 
function count(){ 
bar=bar+2 
amount =amount + line 
document.loading.chart.value=amount 
document.loading.percent.value=bar+"%" 
if (bar<99) 
{setTimeout("count()",100);} 
else 
{window.location = "https://www.google.com.vn/#hl=vi&sclient=psy-ab&q=site:phim.cuatoi.net"} 
}
      </script>
 </script>           <script>  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');  ga('create', 'UA-56022047-1', 'auto');  ga('send', 'pageview');</script>   
<script language="javascript" src="http://xslt.alexa.com/site_stats/js/s/a?url=http://face.cuatoi.net"></script>
</body>
</html>