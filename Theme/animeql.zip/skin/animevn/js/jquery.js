var filmURL  = 'http://face.cuatoi.net'; // Ko có dấu / ở cuối
var http = createRequestObject();

function createRequestObject() {
	var xmlhttp;
	try { xmlhttp=new ActiveXObject("Msxml2.XMLHTTP"); }
	catch(e) {
    try { xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");}
	catch(f) { xmlhttp=null; }
  }
  if(!xmlhttp&&typeof XMLHttpRequest!="undefined") {
	xmlhttp=new XMLHttpRequest();
  }
	return  xmlhttp;
}

// TIM KIEM PHIM
function do_search() {
	kw = document.getElementById("marxgs").value;	
	if (!kw) alert('Bạn chưa nhập tên anime cần tìm !');
	else {
		kw = kw.toLowerCase().replace(/à|á|ạ|ả|ã|â|ầ|ấ|ậ|ẩ|ẫ|ă|ằ|ắ|ặ|ẳ|ẵ/g,"a")
        .replace(/è|é|ẹ|ẻ|ẽ|ê|ề|ế|ệ|ể|ễ/g,"e")
        .replace(/ì|í|ị|ỉ|ĩ/g,"i")
        .replace(/ò|ó|ọ|ỏ|õ|ô|ồ|ố|ộ|ổ|ỗ|ơ|ờ|ớ|ợ|ở|ỡ/g,"o")
        .replace(/ù|ú|ụ|ủ|ũ|ư|ừ|ứ|ự|ử|ữ/g,"u")
        .replace(/ỳ|ý|ỵ|ỷ|ỹ/g,"y")
        .replace(/đ/g,"d")
        .replace(/[éèêë]/g,"e").replace(/[îï]/g,"i")
        .replace(/[ô]/g,"o").replace(/[ùû]/g,"u").replace(/[ñ]/g,"n")
        .replace(/[äæ]/g,"ae").replace(/[öø]/g,"oe").replace(/[ü]/g,"ue")
        .replace(/[ß]/g,"ss").replace(/[å]/g,"aa")
        .replace(/[^-a-z0-9~\s\.:;+=_]/g, '').replace(/[\s\.:;=+]+/g, '+')
		.replace(/-+-/g,"-").replace(/^\-+|\-+$/g,"");
		window.location.href = ''+ filmURL +'/tim-kiem/'+kw+'';	
	}
  return false;
}

$().ready(function() {
	$("#marxgs").autocomplete("http://face.cuatoi.net/search.php", {
		width:276,
		matchContains: true,
		selectFirst: false
	});
});
// BAO FIX LINK EPISODE LOI
function showBroken(film_id,episode_id) {
	var r = confirm("Bạn có chắc chắn tập phim này bị lỗi!");
	if(r==true) {
		$.post("index.php",{error:1,film_id:film_id,episode_id:episode_id},function(c){
			if(c==1) {
jAlert('<br /> \Cảm ơn bạn đã báo lỗi ! Chúng mình sẽ sửa link trong thời gian sớm nhất !', 'Thông báo từ Phim.CuaToi.Net');
			}
		});
	}
	return false;
}
function showBroken1(film_id,episode_id) {
	try {
		http.open('POST',''+ filmURL +'/index.php');
		http.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
		http.onreadystatechange = function() {
			$.ajax({
            success: function (res) {
               jAlert('<br /> \Cảm ơn bạn đã báo lỗi ! Chúng mình sẽ sửa link trong thời gian sớm nhất !', 'Thông báo từ Phim.CuaToi.Net');
            },
            error: function (error) {}
        	});
			/*alert('Đã thông báo link lỗi! Cám ơn bạn!');*/
		}
		http.send('error=1&film_id='+film_id+'&episode_id='+episode_id);
	}
	catch(e){}
	finally{}
	return false;
}
// fuc like
function Like(film_id) {
	try {
		http.open('POST',''+ filmURL +'/index.php');
		http.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
		http.onreadystatechange = function() {
			if((http.readyState == 4)&&(http.status == 200)){
				document.getElementById("likeplayer").innerHTML = http.responseText;
			}
		}
		http.send('like=1&film_id='+film_id);
	}
	catch(e){}
	finally{}
	return false;
}
function scrollTop(){
    var targetOffset = $('#content').offset().top;
    var targetOffset=targetOffset-50;
    $('html,body').animate({scrollTop: targetOffset}, 1000);   
}

// Base64 code from Tyler Akins
var keyStr = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";

function base64_encode(input) {
   var output = "";
   var chr1, chr2, chr3;
   var enc1, enc2, enc3, enc4;
   var i = 0;

   do {
      chr1 = input.charCodeAt(i++);
      chr2 = input.charCodeAt(i++);
      chr3 = input.charCodeAt(i++);

      enc1 = chr1 >> 2;
      enc2 = ((chr1 & 3) << 4) | (chr2 >> 4);
      enc3 = ((chr2 & 15) << 2) | (chr3 >> 6);
      enc4 = chr3 & 63;

      if (isNaN(chr2)) {
         enc3 = enc4 = 64;
      } else if (isNaN(chr3)) {
         enc4 = 64;
      }

      output = output + keyStr.charAt(enc1) + keyStr.charAt(enc2) + 
         keyStr.charAt(enc3) + keyStr.charAt(enc4);
   } while (i < input.length);
   
   return output;
}

function player(input) {
   var output = "";
   var chr1, chr2, chr3;
   var enc1, enc2, enc3, enc4;
   var i = 0;
   input = input.replace(/[^A-Za-z0-9\+\/\=]/g, "");

   do {
      enc1 = keyStr.indexOf(input.charAt(i++));
      enc2 = keyStr.indexOf(input.charAt(i++));
      enc3 = keyStr.indexOf(input.charAt(i++));
      enc4 = keyStr.indexOf(input.charAt(i++));

      chr1 = (enc1 << 2) | (enc2 >> 4);
      chr2 = ((enc2 & 15) << 4) | (enc3 >> 2);
      chr3 = ((enc3 & 3) << 6) | enc4;

      output = output + String.fromCharCode(chr1);

      if (enc3 != 64) {
         output = output + String.fromCharCode(chr2);
      }
      if (enc4 != 64) {
         output = output + String.fromCharCode(chr3);
      }
   } while (i < input.length);

   return output;
}

/* jQuery Alert Dialogs Plugin
Usage:
	jAlert( message, [title, callback] )
	jConfirm( message, [title, callback] )
	jPrompt( message, [value, title, callback] )
*/
(function($){$.InFieldLabels=function(b,c,d){var f=this;f.$label=$(b);f.label=b;f.$field=$(c);f.field=c;f.$label.data("InFieldLabels",f);f.showing=true;f.init=function(){f.options=$.extend({},$.InFieldLabels.defaultOptions,d);if(f.$field.val()!=""){f.$label.hide();f.showing=false};f.$field.focus(function(){f.fadeOnFocus()}).blur(function(){f.checkForEmpty(true)}).bind('keydown.infieldlabel',function(e){f.hideOnChange(e)}).change(function(e){f.checkForEmpty()}).bind('onPropertyChange',function(){f.checkForEmpty()})};f.fadeOnFocus=function(){if(f.showing){f.setOpacity(f.options.fadeOpacity)}};f.setOpacity=function(a){f.$label.stop().animate({opacity:a},f.options.fadeDuration);f.showing=(a>0.0)};f.checkForEmpty=function(a){if(f.$field.val()==""){f.prepForShow();f.setOpacity(a?1.0:f.options.fadeOpacity)}else{f.setOpacity(0.0)}};f.prepForShow=function(e){if(!f.showing){f.$label.css({opacity:0.0}).show();f.$field.bind('keydown.infieldlabel',function(e){f.hideOnChange(e)})}};f.hideOnChange=function(e){if((e.keyCode==16)||(e.keyCode==9))return;if(f.showing){f.$label.hide();f.showing=false};f.$field.unbind('keydown.infieldlabel')};f.init()};$.InFieldLabels.defaultOptions={fadeOpacity:0.5,fadeDuration:300};$.fn.inFieldLabels=function(c){return this.each(function(){var a=$(this).attr('for');if(!a)return;var b=$("input#"+a+"[type='text'],"+"input#"+a+"[type='password'],"+"textarea#"+a);if(b.length==0)return;(new $.InFieldLabels(this,b[0],c))})}})(jQuery);var MARX={};(function($){MARX.Utilities={Cookie:function(a,b,c){if(arguments.length>1&&(!/Object/.test(Object.prototype.toString.call(b))||b===null||b===undefined)){c=$.extend({},c);if(b===null||b===undefined){c.expires=-1}
if(typeof c.expires==='number'){var d=c.expires,t=c.expires=new Date();t.setDate(t.getDate()+d)}
b=String(b);return(document.cookie=[encodeURIComponent(a),'=',c.raw?b:encodeURIComponent(b),c.expires?'; expires='+c.expires.toUTCString():'',c.path?'; path='+c.path:'',c.domain?'; domain='+c.domain:'',c.secure?'; secure':''].join(''))}
c=b||{};var e=c.raw?function(s){return s}:decodeURIComponent;var f=document.cookie.split('; ');for(var i=0,pair;pair=f[i]&&f[i].split('=');i++){if(e(pair[0])===a)return e(pair[1]||'')}
return null},Retop:function(a,b){$('body').animate({scrollTop:($("#"+a).offset().top)-b},'fast');},EXplayer:function(ex){var a=jQuery('#header').outerHeight(true),tl=jQuery('h1.entry-title'),pt=tl.outerHeight(true),mp=jQuery('#movie-player'),mpr=mp.parent(),mpb=$('#explayer'),sb=jQuery('#sidebar'),miw=960,mih=560;if(mpb.attr('active')==1&&ex){sb.css('margin-top',0);mpr.width('auto');tl.width('auto');mp.removeAttr('style');mpb.attr({'title':'Phóng to','active':0}).text('Phóng to');MARX.Utilities.Cookie('explayer',0,{expires:365,path:'/'});}else{sb.css('margin-top',mih+pt+65);mpr.width(960);tl.width(960);mp.css({'width':miw,'height':mih});mpb.attr({'title':'Thu nhỏ','active':1}).text('Thu nhỏ');MARX.Utilities.Cookie('explayer',1,{expires:365,path:'/'});}
MARX.Utilities.Retop('vid-play',30);},Toggle:function(e){$('#'+e).toggle('fast');},Exdesc:function(e){var a=$(e),mdes=$('#description-clip'),atv=a.attr('data-active');if(atv==0){mdes.css('height','auto');a.text('Hiển thị ít hơn').attr('data-active',1);}else{mdes.css('height',150);a.text('Hiển thị đầy đủ').attr('data-active',0);}},Tooltip:function(){var df={xOffset:0,yOffset:10,tooltipId:"Tooltip",};var w=$(window).width();$(".doTooltip").each(function(){var self=$(this);self.hover(function(e){content=self.children('.TooltipContent').html();if(content!=""&&content!=undefined){lr=(self.offset().left<=w/3)?'left':'right';self.after("<div id='"+df.tooltipId+"'><span class='arrow'></span>"+content+"</div>");$("#"+df.tooltipId).css({'position':'absolute','top':e.pageY-self.offset().top-df.yOffset,'display':'none'}).css(lr,self.parent().outerWidth()+df.xOffset).addClass('tooltip_'+lr).fadeIn("normal")}},function(){$("#"+df.tooltipId).remove();}).mousemove(function(e){$("#"+df.tooltipId).css("top",(e.pageY-self.offset().top-df.yOffset)+"px")});});},POP:function(o){var c=$.extend({time:60,link:[],cookie:'__utmk',modal:''},o),m={init:function(){if(MARX.Utilities.Cookie(c.cookie)==null){$.each(c.link,function(i,a){m._mwp(a)});m._ck()}else{$(document).unbind('click',m.init)}},_ck:function(){var d=new Date();d.setTime(d.getTime()+(c.time*60*1000));MARX.Utilities.Cookie(c.cookie,"1",{expires:d,path:'/'})},_mwp:function(a){var b='';if(!a.same){b='width='+a.width+',height='+a.height;if(a.crazy){var ww=$(window).width(),wh=$(window).height();b+=',left='+m._rn(ww)+'px,top='+m._rn(wh)+'px'}}
window.open(a.url,m._rn(500)+'marxvn',b).blur();window.focus()},_rn:function(m){return Math.floor(Math.random()*m)}}
$(document).click(m.init);},BBAR:function(c){var st,v,b=$('#control-bt'),h=function(){b.width(38);$('#ctbt-toggle-l').show();MARX.Utilities.Cookie('bbtoggle','hide',{expires:365,path:'/'});},s=function(){b.width('');$('#ctbt-toggle-l').hide();MARX.Utilities.Cookie('bbtoggle',null,{path:'/'});};v=c?'hide':null;st=(MARX.Utilities.Cookie('bbtoggle')==v)?true:false;if(st){h();}else{s();}},STICKY:function(up){var view=MARX.Utilities.getViewport(),sidebar=$('#inctsb .sbwrapper'),sbpn=sidebar.offset(),btpn=$('.fbcm').offset();if(this.sidebarTop==-1||up){this.sidebarTop=sbpn.top;}
if(this.sidebarTop!=-1){if(view.offsetY>=this.sidebarTop-10){var top=Math.min(10,btpn.top-(view.offsetY+sidebar.outerHeight()));sidebar.addClass('fixed_this').css('top',top+'px').css('width','150px');}else{sidebar.removeClass('fixed_this').css('top','');}}},getViewport:function(){var result={},docElem=document.documentElement,body=document.body;if(window.innerWidth){result.width=window.innerWidth;result.height=window.innerHeight}else{if(docElem&&docElem.offsetWidth){result.width=docElem.offsetWidth;result.height=docElem.offsetHeight}else{result.width=body.offsetWidth;result.height=body.offsetHeight}}
if(MARX.Utilities.isNumber(window.pageYOffset)){result.offsetY=window.pageYOffset;result.offsetX=window.pageXOffset}else{if(docElem&&(docElem.scrollLeft||docElem.scrollTop)){result.offsetY=docElem.scrollTop;result.offsetX=docElem.scrollLeft}else{if(body&&(MARX.Utilities.isNumber(body.scrollLeft))){result.offsetY=body.scrollTop;result.offsetX=body.scrollLeft}}}
return result},isNumber:function(obj){return typeof obj=="number"},Dialog:function(obj){var p={w:720,h:480,t:'Dialog',d:!1},r=$.extend({},p,obj),s=$('body'),v={m:'mxDl_m',i:'mxDl',q:'mxDl_q',z:1e5,to:null},iz=function(){if(r.d){ov();sq();}}
ov=function(){$("<div/>",{"class":"mMask",id:v.m,css:{zIndex:(v.z-1),height:$(document).height(),position:'fixed',top:0,left:0,right:0,bottom:0,display:'block',background:'#000'}}).appendTo(s).fadeIn(1e3).fadeTo("slow",0.8);return cc();},cc=function(){$("<div/>",{"class":"mDl",id:v.i,css:{zIndex:v.z,width:r.w,height:r.h+25,position:'fixed'},html:'<div class="mxDl_t">'+r.t+'</div><div class="mxDL_ct" style="height:'+parseInt(r.h)+'px">'+r.d+'</div>'}).appendTo(s);return cp();},cp=function(){var wh=$(window).height();var ww=$(window).width();return $('#'+v.i).css({top:wh/2-r.h/2-27,left:ww/2-r.w/2});},sq=function(y){var g=$('<a/>',{href:'javascript:void(0)','class':v.q,text:'[ x ]',click:function(){dc();}});return $('#'+v.i).append(g);},dc=function(){delete(r);return $('#'+v.m+','+'#'+v.i).remove();};return iz();},YTTL:function(e){var s=$(e),id=s.attr('data-id'),id=id.replace(/watch\?v=/g, "embed/");MARX.Utilities.Dialog({w:640,h:378,t:s.attr('title'),d:'<iframe width="640" height="360" src="'+id+'?showinfo=0&amp;autoplay=1" frameborder="0" allowfullscreen></iframe>'});}}})(jQuery);jQuery(document).ready(function($){$(".placeholder").inFieldLabels();MARX.Utilities.Tooltip();});