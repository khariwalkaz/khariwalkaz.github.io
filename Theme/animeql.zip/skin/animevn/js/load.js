function load_video(e_id) {
	if (e_id != 0)
		$.post("index.php", {
			nextmovie : 1,
			e_id : e_id
		}, function (data) {
			if (data) {
				$("#movie-player").html(data);
				$("#" + e_id).addClass("epchon");
			}
		});
}
//info - js