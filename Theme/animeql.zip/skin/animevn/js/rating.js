function nextmovie(){
	current = $('.episodelist').find('a.epchon');
	nextitem = current.next('a');
	if(nextitem.attr('href')){
		location = nextitem.attr('href');
	}
}
function load_video(e_id) {
	if (e_id != 0)
		$.post("index.php", {
			nextmovie : 1,
			e_id : e_id
		}, function (data) {
			if (data) {
				$("#movie-player").html(data);
			}
		});
}
function rating(film_id,star) {
	try {
		document.getElementById("rate_s").innerHTML = loadingText;
		document.getElementById("rate_s").style.display = "block";
		hide_rating_process();
		http.open('POST',  'index.php');
		http.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
		http.onreadystatechange = function() {
			if((http.readyState == 4)&&(http.status == 200)){
				document.getElementById("rating_field").innerHTML = http.responseText;
			}
		}
		http.send('rating=1&film_id='+film_id+'&star='+star);
	}
	catch(e){}
	finally{}
	return false;
}