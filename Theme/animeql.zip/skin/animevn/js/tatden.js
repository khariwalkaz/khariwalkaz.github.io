$(function () {
	// search
    $("#do_search").click(function () {
        do_search();
    });
    $("#keyword").click(function () {
        if ($(this).val() == 'Từ khóa tìm kiếm...') {
            $(this).val('');
        }
    });
	//rate film
    $(".film_action .star_items .rate").mouseenter(function () {
        filmid = $("#filmid").val();
        star = $(this).attr("data-id");
        if (filmid) {
            $.each($(this).parent().find('.rate'), function (key) {
                $(this).removeClass('none half full');
                if (key < star) {
                    $(this).addClass('full');
                }
            });
            $(".rate_result").hide();
            $(".star_meaning").text($(this).attr("data-meaning"));
        }
    }).mouseleave(function () {
        if (filmid) {
            $.each($(this).parent().find('.rate'), function (key) {
                $(this).removeClass('none full').addClass($(this).attr("data"));
            });
            $(".rate_result").show();
            $(".star_meaning").text('');
        }
    }).click(function () {
        if (filmid) {
            rate_film(filmid, star);
            filmid = null;
            $("#filmid").val(null);
        }
    });
	// ajax episode
    $(".episodelist").find("a").click(function () {
        load_episode($(this));
        return false;
    });
	// toggle phim info in watch page
    $(".show.filminfo, .panel.filminfo .close").click(function () {
        $(".panel.filminfo").slideToggle('slow');
    });
	// toggle phim like in watch page
    $(".show.filmlike, .panel.filmlike .close").click(function () {
        $(".panel.filmlike").slideToggle('slow');
    });
	// toggle phim dislike in watch page
    $(".show.filmdislike, .panel.filmdislike .close").click(function () {
        $(".panel.filmdislike").slideToggle('slow');
    });
	// init light out, resize player
    $("#toggle_light, #toggle_resize, #toggle_autonext").show();
    $("#movie.block").css("position", "absolute");
    $("#movie_info").css('margin-top', '500px');
    if (!$("#player").length) {
        $("#movie_info").css('margin-top', 100);
		$("#movie.block").css('height', 100);
    }
	// resize
    $("#toggle_resize").click(function () {
        resize_player();
        $(this).text(resize ? 'Thu nhỏ' : 'Phóng to');
    });
	// light out
    var lightout = false;
    $("#movie-player, #toggle_resize, #mediaplayer, #vid-play, .play-area, #explayer, #player, #toggle_light, #likeplayer, #explayer-1, .luotxem, .download_phim, .fb-like, .button_watch").css("position", "relative").css('z-index', 8);
    $("#toggle_light, #lightout").click(function () {
        if (!lightout) {
            lightout = true;
            $("#lightout").css("opacity", 0.98).hide().fadeIn();
        } else {
            lightout = false;
            $("#lightout").fadeOut();
        }
        $("#toggle_light").text(lightout ? 'Bật đèn' : 'Tắt đèn');
    });
	// report film die
    $(".film_link .report a").click(function () {
        report_film_die($(this).attr('filmid'));
    });
	// tooltip phim
    $(".poster a").each(function () {
		$(this).easyTooltip({
            'content': $(this).parents('li').find('.tooltip').html()
        });
    });
   
});