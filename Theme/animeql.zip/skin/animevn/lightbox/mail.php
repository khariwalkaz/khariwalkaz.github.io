<?php
include("class.phpmailer.php");
include("class.smtp.php");
$mail = new PHPMailer();
$mail->IsSMTP(); // set mailer to use SMTP
$mail->Host = "smtp.gmail.com"; // specify main and backup server
$mail->Port = 465; // set the port to use
$mail->SMTPAuth = true; // turn on SMTP authentication
$mail->SMTPSecure = 'ssl';
$mail->Username = "info.cuatoi@gmail.com"; // your SMTP username or your gmail username
$mail->Password = "2255881122"; // your SMTP password or your gmail password
$from = "nguyenkimnam89@gmail.com"; // Reply to this email
$to = "nguyenkimnam89@gmail.com"; // Recipients email ID
$name = 'Yêu cầu Phim'; // Recipient's name
$mail->CharSet = 'utf-8';
$mail->From = $from;
$mail->FromName = 'Yêu cầu Phim'; // Name to indicate where the email came from when the recepient received
$mail->AddAddress($to,$name);
$mail->AddReplyTo($from,'Yêu cầu Phim');
$mail->WordWrap = 50; // set word wrap
$mail->IsHTML(true); // send as HTML
// bat dau gui mail
$maildk = $_POST['email'];
$tendk = $_POST['fullname'];
$noidung = $_POST['comments'];

if ($maildk !=NULL && $tendk !=NULL && $noidung !=NULL && (eregi('^[a-zA-Z0-9._-]+@[a-zA-Z0-9._-]+\.([a-zA-Z]{2,4})$',$maildk)))
{
if (!empty($_SERVER['HTTP_CLIENT_IP'])) {  //check ip from share internet
	$ip = $_SERVER['HTTP_CLIENT_IP'];
} elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
	//to check ip is pass from proxy
	$ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
} else {
	$ip = $_SERVER['REMOTE_ADDR'];
}
$_SERVER['REMOTE_ADDR'] = $ip;
$dt = date("l dS \of F Y h:i:s A")."\n".file_get_contents("log_ip.txt");
$file=fopen("log_ip.txt","w"); 
$data = $ip.' '.$dt."\n"; 
fwrite($file, $data); 
fclose($file);
$mail->Subject = 'Tên: '.$tendk.' Yêu cầu Phim';
$mail->Body = 'Email  '.$maildk.' - Tên: '.$tendk.'- ip '.$ip.'
<br>
Nội Dung: <b>'.$noidung.'</b>'; //HTML Body
$mail->AltBody = 'Email  '.$maildk.' - Tên: '.$tendk.'
<br>
Nội Dung: <b>'.$noidung.'</b>'; //Text Body
$mail->Send();
?>
<html>
<head>
<meta content="text/html; charset=utf-8" http-equiv=Content-Type />
<title>Đã gửi góp ý thành công</title>
</head>
<body>
<script>
	if (confirm("Cảm ơn bạn đã gửi yêu cầu !\nChúng tôi sẽ update nhanh nhất nếu có thể !")) {
	history.go(-1);
	vote();
	}
	else history.go(-1)
</script>
</body>
</html>
<?php
}
else{
if (!empty($_SERVER['HTTP_CLIENT_IP'])) {  //check ip from share internet
	$ip = $_SERVER['HTTP_CLIENT_IP'];
} elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
	//to check ip is pass from proxy
	$ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
} else {
	$ip = $_SERVER['REMOTE_ADDR'];
}
$_SERVER['REMOTE_ADDR'] = $ip;
$dt = date("l dS \of F Y h:i:s A")."\n".file_get_contents("log_ip.txt");
$file=fopen("log_ip.txt","w"); 
$data = $ip.' '.$dt."\n"; 
fwrite($file, $data); 
fclose($file);
?>
<!DOCTYPE html>
<html>
<head>
<meta content="text/html; charset=utf-8" http-equiv="Content-Type" />
<title>Có lỗi trong quá trình gửi</title>
</head>
<body>
<script type="text/javascript">
	if (confirm("Yêu cầu bạn nhập đầy đủ hợp lệ thông tin yêu cầu.\nHãy kiểm tra lại email của bạn lại nhé.")) {
	history.go(-1);
	vote();
	}
	else history.go(-1);
</script>
</body>
</html>
<?php
}
?>