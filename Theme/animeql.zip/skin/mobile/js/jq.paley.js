function nextmovie(){
	current = $('.eplist').find('a.selec');
	nextitem = current.next('a');
	if(nextitem.attr('href')){
		location = nextitem.attr('href');
	}
}