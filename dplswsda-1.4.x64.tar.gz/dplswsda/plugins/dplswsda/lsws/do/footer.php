<div style="text-align: center;font-size: 1.0em; color: #888888;">
<span id="valid">
Copyright &copy; 2012-2015 <a  style="color: #0570b9;" onclick="window.open('http://www.datapool.vn')"> DATAPOOL.VN BY DARKMAGICIAN</a> 
</span>
</div>