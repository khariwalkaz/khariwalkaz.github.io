<?
/********************************************
* LiteSpeed Plugin for DA
* @Author:   DataPool, Inc. (http://www.datapool.vn)
* @Copyright: (c) 2012-2015
*********************************************/
?>

<?php
function proc_exec($cmd){
$handle = popen("$cmd", 'r');
while(!feof($handle)) {
    $buffer = fgets($handle);
    echo "$buffer<br/>\n";
    ob_flush();
    flush();
        }
pclose($handle);
}
?>

<?php
$RVERSION = `/usr/bin/curl -s http://datapoolvn.com/DirectAdmin/dplswsda/version.txt`;
$LVERSION = `/bin/cat /usr/local/directadmin/plugins/dplswsda/lsws/version.txt`;
?>

<html>
<body>
<div id="pageheader">
        <div id="breadcrumbs">
                <p>&nbsp;<a href="/CMD_PLUGINS_ADMIN/">Plugins</a>&nbsp;&gt;&gt;&nbsp;<a href="../index.html">DPLiteSpeedDA Manager</a></p>
        </div>
</div>
<div class="topboxmargin"></div>
<div style="margin-left:20;margin-right:20">
</div>
</body>
</html>
<table border="0" align="center" width="100%">
<tr><td><center><img alt="DPLiteSpeedDA" src="../images/datapool_logo.png"/ onclick="window.open('http://www.datapool.vn')" ></center></td></tr>
  <tr class="scellheader"> 
  </tr>
  <tr><td>&nbsp;</td></tr>
</table>
<?php

function LiteSpeed_status($status){
        $handle = popen("$status", 'r');
        while(!feof($handle)) {
                $ret = fgets($handle);
                echo "<b>$ret</b>";
        }
        pclose($handle);
}

function Versiondplswsda(){
 $flines=file("/usr/local/directadmin/plugins/dplswsda/lsws/version.txt");
 foreach ($flines as $line_num => $line){ 
		echo $line;
        }
}

function VersionLiteSpeed(){
 $flines=file("/usr/local/directadmin/plugins/dplswsda/lsws/lswsver.txt");
 foreach ($flines as $line_num => $line){
		echo $line;
        }
}
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
</head>
<div class="content2">
<strong><font color="#0570b9">LiteSpeed Status:</font> <?php LiteSpeed_status("if  pgrep litespeed   &> /dev/null; then echo -ne \"<font color=\"green\">Online</font>\"; else echo -ne \"<font color=\"red\">Offline</font>\"; fi "); ?></strong>&nbsp;&nbsp;&nbsp;&nbsp;<strong><font color="#0570b9">DPLSWSDA Version: </font><font color="green"><?php Versiondplswsda(); ?></font></strong>&nbsp;&nbsp;&nbsp;&nbsp;<strong><font color="#0570b9">LiteSpeed Version: </font><font color="green"><?php VersionLiteSpeed(); ?></font></strong><br /> <br /> <br />

<body>
<p>
<?php
proc_exec("/usr/local/directadmin/plugins/dplswsda/exec/update.exec");
?>
<form action="checkupdate.do" method="post">
<strong><font color="#0570b9">Check Update DPLSWSDA </font></strong> <input type="submit" name="submit" value="Check">
</form>
<form action="update.do" method="post">
<strong><font color="#0570b9">Update DPLSWSDA </font></strong> <input type="submit" name="submit" value="Update">
</form>
</p>

</div>
<br /><br /><br /><br /><br /><br />
<p>
<?php include('footer.php');
?>
</p>
<p style="margin-top:30px;color:#a0a0a0;text-align:right">This plugin is developed by DARKMAGICIAN, DirectAdmin is not responsible for 
support.<br/>Please contact DataPool for all related questions and issues.<br/><br/>LiteSpeed Plugin for DirectAdmin 
v1.5.3 </p>
</html>