#!/usr/bin/perl
###############################################################################
# Copyright 2012 - 2015, DARKMAGICIAN
# URL: http://www.datapool.vn
###############################################################################
# start main
use IPC::Open3;

&printcmd("touch /usr/local/directadmin/scripts/lsws/auto.file");

sub printcmd {
        my $cmd = shift;
        my ($childin, $childout);
        my $pid = open3($childin, $childout, $childout, $cmd);
        while (<$childout>) {print $_}
        waitpid ($pid, 0);
}
