#!/usr/bin/perl
###############################################################################
# Copyright 2012 - 2015, DARKMAGICIAN
# URL: http://www.datapool.vn
###############################################################################
# start main
use IPC::Open3;

&printcmd("/etc/init.d/litespeed stop");

sub printcmd {
        my $cmd = shift;
        my ($childin, $childout);
        my $pid = open3($childin, $childout, $childout, $cmd);
        while (<$childout>) {print $_}
        waitpid ($pid, 0);
}
